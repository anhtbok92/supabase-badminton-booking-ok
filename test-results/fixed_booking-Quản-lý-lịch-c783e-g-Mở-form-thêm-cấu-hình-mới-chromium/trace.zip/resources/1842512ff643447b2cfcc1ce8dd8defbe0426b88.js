(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/app/admin/_components/booking-manager.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BookingManager",
    ()=>BookingManager
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$format$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/date-fns/format.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$locale$2f$vi$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/date-fns/locale/vi.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$antd$2f$es$2f$date$2d$picker$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DatePicker$3e$__ = __turbopack_context__.i("[project]/node_modules/antd/es/date-picker/index.js [app-client] (ecmascript) <export default as DatePicker>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$antd$2f$es$2f$config$2d$provider$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__ConfigProvider$3e$__ = __turbopack_context__.i("[project]/node_modules/antd/es/config-provider/index.js [app-client] (ecmascript) <locals> <export default as ConfigProvider>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$antd$2f$locale$2f$vi_VN$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/antd/locale/vi_VN.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$dayjs$2f$dayjs$2e$min$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/dayjs/dayjs.min.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$dayjs$2f$locale$2f$vi$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/dayjs/locale/vi.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ant$2d$design$2f$nextjs$2d$registry$2f$es$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@ant-design/nextjs-registry/es/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ant$2d$design$2f$nextjs$2d$registry$2f$es$2f$AntdRegistry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AntdRegistry$3e$__ = __turbopack_context__.i("[project]/node_modules/@ant-design/nextjs-registry/es/AntdRegistry.js [app-client] (ecmascript) <export default as AntdRegistry>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$supabase$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/supabase/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$supabase$2f$provider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/supabase/provider.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$supabase$2f$hooks$2f$use$2d$query$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/supabase/hooks/use-query.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/input.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/table.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/badge.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$use$2d$toast$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/use-toast.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$skeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/skeleton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/dropdown-menu.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$ellipsis$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MoreHorizontal$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/ellipsis.js [app-client] (ecmascript) <export default as MoreHorizontal>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2d$2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash2$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/trash-2.js [app-client] (ecmascript) <export default as Trash2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$zoom$2d$in$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ZoomIn$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/zoom-in.js [app-client] (ecmascript) <export default as ZoomIn>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$zoom$2d$out$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ZoomOut$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/zoom-out.js [app-client] (ecmascript) <export default as ZoomOut>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeft$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-left.js [app-client] (ecmascript) <export default as ChevronLeft>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-right.js [app-client] (ecmascript) <export default as ChevronRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle2$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/circle-check.js [app-client] (ecmascript) <export default as CheckCircle2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$file$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FileDown$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/file-down.js [app-client] (ecmascript) <export default as FileDown>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/dialog.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/select.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jspdf$2f$dist$2f$jspdf$2e$es$2e$min$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/jspdf/dist/jspdf.es.min.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$html2canvas$2f$dist$2f$html2canvas$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/html2canvas/dist/html2canvas.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$dayjs$2f$dayjs$2e$min$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].locale('vi');
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function ImageViewer(param) {
    let { imageUrls, startIndex, isOpen, onClose } = param;
    _s();
    const [currentIndex, setCurrentIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(startIndex);
    const [zoom, setZoom] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ImageViewer.useEffect": ()=>{
            if (isOpen) {
                setCurrentIndex(startIndex);
                setZoom(1);
            }
        }
    }["ImageViewer.useEffect"], [
        isOpen,
        startIndex
    ]);
    if (!isOpen || !imageUrls || imageUrls.length === 0) return null;
    const currentImage = imageUrls[currentIndex];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Dialog"], {
        open: isOpen,
        onOpenChange: (open)=>!open && onClose(),
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogContent"], {
            className: "max-w-7xl w-full h-[90vh] flex flex-col p-0 gap-0",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogHeader"], {
                    className: "p-4 border-b",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogTitle"], {
                            children: "Xem bằng chứng thanh toán"
                        }, void 0, false, {
                            fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                            lineNumber: 41,
                            columnNumber: 56
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogDescription"], {
                            children: [
                                "Ảnh ",
                                currentIndex + 1,
                                " trên ",
                                imageUrls.length,
                                "."
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                            lineNumber: 41,
                            columnNumber: 108
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                    lineNumber: 41,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex-grow min-h-0 relative flex items-center justify-center overflow-auto bg-muted/50",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        src: currentImage,
                        alt: "Bằng chứng thanh toán ".concat(currentIndex + 1),
                        width: 1920,
                        height: 1080,
                        className: "block object-contain h-auto w-auto max-h-full max-w-full transition-transform duration-200",
                        style: {
                            transform: "scale(".concat(zoom, ")")
                        }
                    }, currentImage, false, {
                        fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                        lineNumber: 43,
                        columnNumber: 21
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                    lineNumber: 42,
                    columnNumber: 17
                }, this),
                imageUrls.length > 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                            variant: "ghost",
                            size: "icon",
                            onClick: ()=>{
                                setCurrentIndex((prev)=>(prev - 1 + imageUrls.length) % imageUrls.length);
                                setZoom(1);
                            },
                            className: "absolute left-4 top-1/2 -translate-y-1/2 h-12 w-12 rounded-full bg-black/30 hover:bg-black/50 text-white z-10",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeft$3e$__["ChevronLeft"], {
                                className: "h-8 w-8"
                            }, void 0, false, {
                                fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                lineNumber: 46,
                                columnNumber: 288
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                            lineNumber: 46,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                            variant: "ghost",
                            size: "icon",
                            onClick: ()=>{
                                setCurrentIndex((prev)=>(prev + 1) % imageUrls.length);
                                setZoom(1);
                            },
                            className: "absolute right-4 top-1/2 -translate-y-1/2 h-12 w-12 rounded-full bg-black/30 hover:bg-black/50 text-white z-10",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__["ChevronRight"], {
                                className: "h-8 w-8"
                            }, void 0, false, {
                                fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                lineNumber: 47,
                                columnNumber: 270
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                            lineNumber: 47,
                            columnNumber: 21
                        }, this)
                    ]
                }, void 0, true),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex-shrink-0 flex items-center justify-center gap-2 p-4 border-t bg-background",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                            variant: "outline",
                            size: "sm",
                            onClick: ()=>setZoom((prev)=>Math.max(prev - 0.2, 0.5)),
                            disabled: zoom <= 0.5,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$zoom$2d$out$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ZoomOut$3e$__["ZoomOut"], {
                                    className: "h-4 w-4 mr-2"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                    lineNumber: 50,
                                    columnNumber: 139
                                }, this),
                                " Thu nhỏ"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                            lineNumber: 50,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                            variant: "outline",
                            size: "sm",
                            onClick: ()=>setZoom(1),
                            disabled: zoom === 1,
                            children: "Reset"
                        }, void 0, false, {
                            fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                            lineNumber: 51,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                            variant: "outline",
                            size: "sm",
                            onClick: ()=>setZoom((prev)=>Math.min(prev + 0.2, 3)),
                            disabled: zoom >= 3,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$zoom$2d$in$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ZoomIn$3e$__["ZoomIn"], {
                                    className: "h-4 w-4 mr-2"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                    lineNumber: 52,
                                    columnNumber: 135
                                }, this),
                                " Phóng to"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                            lineNumber: 52,
                            columnNumber: 21
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                    lineNumber: 49,
                    columnNumber: 17
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
            lineNumber: 40,
            columnNumber: 13
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
        lineNumber: 39,
        columnNumber: 9
    }, this);
}
_s(ImageViewer, "S0ZF2q8UjiWNdZngblqotE2nVH4=");
_c = ImageViewer;
function BookingManager(param) {
    let { userProfile, highlightedBookingId, onHighlightCleared } = param;
    _s1();
    const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$supabase$2f$provider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSupabase"])();
    const { toast } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$use$2d$toast$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useToast"])();
    const { data: allBookings, loading: bookingsLoading, refetch: refetchBookings } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$supabase$2f$hooks$2f$use$2d$query$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSupabaseQuery"])('bookings', undefined, {
        pollingInterval: 5000
    });
    const [viewerState, setViewerState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        isOpen: false,
        urls: [],
        startIndex: 0
    });
    const [statusFilter, setStatusFilter] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('all');
    const [searchTerm, setSearchTerm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [dateRange, setDateRange] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        "BookingManager.useState": ()=>{
            return [
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$dayjs$2f$dayjs$2e$min$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])().startOf('day'),
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$dayjs$2f$dayjs$2e$min$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])().add(3, 'month').endOf('day')
            ];
        }
    }["BookingManager.useState"]);
    const [page, setPage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    const [rowsPerPage, setRowsPerPage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(100);
    const [selectedOwnerId, setSelectedOwnerId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('all');
    const [selectedClubId, setSelectedClubId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('all');
    const [creationDateRange, setCreationDateRange] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const { data: allClubs } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$supabase$2f$hooks$2f$use$2d$query$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSupabaseQuery"])('clubs');
    const { data: owners, loading: ownersLoading } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$supabase$2f$hooks$2f$use$2d$query$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSupabaseQuery"])(userProfile.role === 'admin' ? 'users' : null, {
        "BookingManager.useSupabaseQuery": (q)=>q.eq('role', 'club_owner')
    }["BookingManager.useSupabaseQuery"]);
    const loading = bookingsLoading || userProfile.role === 'admin' && ownersLoading;
    const prevBookingsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "BookingManager.useEffect": ()=>{
            if (loading || !allBookings) return;
            if (prevBookingsRef.current === null) {
                prevBookingsRef.current = allBookings;
                return;
            }
            if (allBookings.length > prevBookingsRef.current.length) {
                const prevBookingIds = new Set(prevBookingsRef.current.map({
                    "BookingManager.useEffect": (b)=>b.id
                }["BookingManager.useEffect"]));
                const newBookings = allBookings.filter({
                    "BookingManager.useEffect.newBookings": (b)=>!prevBookingIds.has(b.id)
                }["BookingManager.useEffect.newBookings"]);
                newBookings.forEach({
                    "BookingManager.useEffect": (booking)=>{
                        if (booking.status === 'Chờ xác nhận') {
                            var _userProfile_managed_club_ids;
                            const isRelevant = userProfile.role === 'admin' || userProfile.role === 'club_owner' && ((_userProfile_managed_club_ids = userProfile.managed_club_ids) === null || _userProfile_managed_club_ids === void 0 ? void 0 : _userProfile_managed_club_ids.includes(booking.club_id));
                            if (isRelevant) {
                                toast({
                                    title: "Có lịch đặt mới!",
                                    description: "".concat(booking.name, " vừa đặt sân tại ").concat(booking.club_name, ".")
                                });
                            }
                        }
                    }
                }["BookingManager.useEffect"]);
            }
            prevBookingsRef.current = allBookings;
        }
    }["BookingManager.useEffect"], [
        allBookings,
        loading,
        toast,
        userProfile
    ]);
    const filteredBookings = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "BookingManager.useMemo[filteredBookings]": ()=>{
            if (!allBookings) return [];
            let bookingsToFilter = allBookings;
            if (userProfile.role === 'admin' && selectedOwnerId !== 'all') {
                const selectedOwner = owners === null || owners === void 0 ? void 0 : owners.find({
                    "BookingManager.useMemo[filteredBookings]": (o)=>o.id === selectedOwnerId
                }["BookingManager.useMemo[filteredBookings]"]);
                const ownerClubIds = (selectedOwner === null || selectedOwner === void 0 ? void 0 : selectedOwner.managed_club_ids) || [];
                bookingsToFilter = bookingsToFilter.filter({
                    "BookingManager.useMemo[filteredBookings]": (b)=>ownerClubIds.includes(b.club_id)
                }["BookingManager.useMemo[filteredBookings]"]);
            } else if (userProfile.role === 'club_owner') {
                bookingsToFilter = bookingsToFilter.filter({
                    "BookingManager.useMemo[filteredBookings]": (b)=>{
                        var _userProfile_managed_club_ids;
                        return (_userProfile_managed_club_ids = userProfile.managed_club_ids) === null || _userProfile_managed_club_ids === void 0 ? void 0 : _userProfile_managed_club_ids.includes(b.club_id);
                    }
                }["BookingManager.useMemo[filteredBookings]"]);
            }
            const finalFiltered = bookingsToFilter.filter({
                "BookingManager.useMemo[filteredBookings].finalFiltered": (booking)=>{
                    const statusMatch = statusFilter === 'all' || booking.status === statusFilter;
                    const clubMatch = selectedClubId === 'all' || booking.club_id === selectedClubId;
                    let dateMatch = true;
                    if (dateRange && dateRange[0] && dateRange[1]) {
                        const bookingDate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$dayjs$2f$dayjs$2e$min$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(booking.date + 'T00:00:00');
                        dateMatch = (bookingDate.isAfter(dateRange[0], 'day') || bookingDate.isSame(dateRange[0], 'day')) && (bookingDate.isBefore(dateRange[1], 'day') || bookingDate.isSame(dateRange[1], 'day'));
                    }
                    const term = searchTerm.trim().toLowerCase();
                    const searchMatch = !term || (booking.phone || '').toLowerCase().includes(term) || (booking.name || '').toLowerCase().includes(term);
                    const systemExcludeMatch = booking.phone.toLowerCase() !== 'hệ thống';
                    let creationDateMatch = true;
                    if (creationDateRange && creationDateRange[0] && creationDateRange[1]) {
                        const createdAt = booking.created_at ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$dayjs$2f$dayjs$2e$min$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(booking.created_at) : null;
                        if (createdAt) {
                            creationDateMatch = (createdAt.isAfter(creationDateRange[0], 'day') || createdAt.isSame(creationDateRange[0], 'day')) && (createdAt.isBefore(creationDateRange[1], 'day') || createdAt.isSame(creationDateRange[1], 'day'));
                        } else {
                            creationDateMatch = false;
                        }
                    }
                    const isDeletedMatch = !booking.is_deleted;
                    return statusMatch && dateMatch && searchMatch && clubMatch && systemExcludeMatch && creationDateMatch && isDeletedMatch;
                }
            }["BookingManager.useMemo[filteredBookings].finalFiltered"]);
            return finalFiltered.sort({
                "BookingManager.useMemo[filteredBookings]": (a, b)=>new Date(b.created_at || 0).getTime() - new Date(a.created_at || 0).getTime()
            }["BookingManager.useMemo[filteredBookings]"]);
        }
    }["BookingManager.useMemo[filteredBookings]"], [
        allBookings,
        userProfile,
        statusFilter,
        dateRange,
        selectedOwnerId,
        owners,
        searchTerm,
        selectedClubId,
        creationDateRange
    ]);
    const groupedBookings = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "BookingManager.useMemo[groupedBookings]": ()=>{
            const groups = {};
            filteredBookings.forEach({
                "BookingManager.useMemo[groupedBookings]": (booking)=>{
                    const createdAtStr = booking.created_at ? Math.floor(new Date(booking.created_at).getTime() / 1000).toString() : 'no-time';
                    const proofsKey = (booking.payment_proof_image_urls || []).sort().join(',');
                    const key = booking.booking_group_id || "".concat(booking.phone, "-").concat(booking.status, "-").concat(createdAtStr, "-").concat(proofsKey);
                    if (!groups[key]) {
                        groups[key] = {
                            id: "group-".concat(key),
                            name: booking.name,
                            phone: booking.phone,
                            totalPrice: 0,
                            count: 0,
                            dates: [],
                            bookingIds: [],
                            paymentProofImageUrls: [],
                            bookings: [],
                            statuses: new Set(),
                            slotsByDate: {},
                            latestCreatedAt: booking.created_at || null,
                            bookingGroupId: booking.booking_group_id || null
                        };
                    }
                    const g = groups[key];
                    g.totalPrice += booking.total_price;
                    g.count += 1;
                    if (!g.dates.includes(booking.date)) g.dates.push(booking.date);
                    g.bookingIds.push(booking.id);
                    if (booking.payment_proof_image_urls) g.paymentProofImageUrls.push(...booking.payment_proof_image_urls);
                    g.bookings.push(booking);
                    g.statuses.add(booking.status);
                    if (booking.created_at && (!g.latestCreatedAt || new Date(booking.created_at).getTime() > new Date(g.latestCreatedAt).getTime())) {
                        g.latestCreatedAt = booking.created_at;
                    }
                    if (!g.slotsByDate[booking.date]) {
                        g.slotsByDate[booking.date] = [];
                    }
                    booking.slots.forEach({
                        "BookingManager.useMemo[groupedBookings]": (s)=>{
                            if (!g.slotsByDate[booking.date].some({
                                "BookingManager.useMemo[groupedBookings]": (existing)=>existing.time === s.time && existing.courtName === s.court_name
                            }["BookingManager.useMemo[groupedBookings]"])) {
                                g.slotsByDate[booking.date].push({
                                    time: s.time,
                                    courtName: s.court_name || ''
                                });
                            }
                        }
                    }["BookingManager.useMemo[groupedBookings]"]);
                }
            }["BookingManager.useMemo[groupedBookings]"]);
            return Object.values(groups).map({
                "BookingManager.useMemo[groupedBookings]": (g)=>({
                        ...g,
                        dates: g.dates.sort({
                            "BookingManager.useMemo[groupedBookings]": (a, b)=>b.localeCompare(a)
                        }["BookingManager.useMemo[groupedBookings]"]),
                        paymentProofImageUrls: Array.from(new Set(g.paymentProofImageUrls)),
                        statusSummary: Array.from(g.statuses).join(', '),
                        slotsByDate: Object.fromEntries(Object.entries(g.slotsByDate).map({
                            "BookingManager.useMemo[groupedBookings]": (param)=>{
                                let [date, slots] = param;
                                return [
                                    date,
                                    slots.sort({
                                        "BookingManager.useMemo[groupedBookings]": (a, b)=>a.time.localeCompare(b.time)
                                    }["BookingManager.useMemo[groupedBookings]"])
                                ];
                            }
                        }["BookingManager.useMemo[groupedBookings]"]))
                    })
            }["BookingManager.useMemo[groupedBookings]"]);
        }
    }["BookingManager.useMemo[groupedBookings]"], [
        filteredBookings
    ]);
    const pageCount = Math.ceil(groupedBookings.length / rowsPerPage);
    const paginatedBookings = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "BookingManager.useMemo[paginatedBookings]": ()=>{
            const startIndex = (page - 1) * rowsPerPage;
            return groupedBookings.slice(startIndex, startIndex + rowsPerPage);
        }
    }["BookingManager.useMemo[paginatedBookings]"], [
        groupedBookings,
        page,
        rowsPerPage
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "BookingManager.useEffect": ()=>{
            if (!highlightedBookingId || !allBookings || loading) return;
            const targetBooking = allBookings.find({
                "BookingManager.useEffect.targetBooking": (b)=>b.id === highlightedBookingId
            }["BookingManager.useEffect.targetBooking"]);
            if (targetBooking) {
                if (statusFilter !== 'all') setStatusFilter('all');
                if (searchTerm !== '') setSearchTerm('');
                if (selectedOwnerId !== 'all') setSelectedOwnerId('all');
                if (selectedClubId !== 'all') setSelectedClubId('all');
                const bDate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$dayjs$2f$dayjs$2e$min$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(targetBooking.date + 'T00:00:00');
                if (!dateRange || !dateRange[0] || !dateRange[1] || bDate.isBefore(dateRange[0], 'day') || bDate.isAfter(dateRange[1], 'day')) {
                    setDateRange([
                        bDate.startOf('month'),
                        bDate.endOf('month')
                    ]);
                }
            }
        }
    }["BookingManager.useEffect"], [
        highlightedBookingId,
        allBookings,
        loading
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "BookingManager.useEffect": ()=>{
            if (!highlightedBookingId || groupedBookings.length === 0) return;
            const groupIndex = groupedBookings.findIndex({
                "BookingManager.useEffect.groupIndex": (g)=>g.bookingIds.includes(highlightedBookingId)
            }["BookingManager.useEffect.groupIndex"]);
            if (groupIndex !== -1) {
                const targetPage = Math.floor(groupIndex / rowsPerPage) + 1;
                if (page !== targetPage) {
                    setPage(targetPage);
                    return;
                }
                const activeGroup = groupedBookings[groupIndex];
                const timer = setTimeout({
                    "BookingManager.useEffect.timer": ()=>{
                        const element = document.getElementById("booking-".concat(activeGroup.id));
                        if (element) {
                            element.scrollIntoView({
                                behavior: 'smooth',
                                block: 'center'
                            });
                            const clearTimer = setTimeout({
                                "BookingManager.useEffect.timer.clearTimer": ()=>{
                                    onHighlightCleared === null || onHighlightCleared === void 0 ? void 0 : onHighlightCleared();
                                }
                            }["BookingManager.useEffect.timer.clearTimer"], 5000);
                            return ({
                                "BookingManager.useEffect.timer": ()=>clearTimeout(clearTimer)
                            })["BookingManager.useEffect.timer"];
                        }
                    }
                }["BookingManager.useEffect.timer"], 300);
                return ({
                    "BookingManager.useEffect": ()=>clearTimeout(timer)
                })["BookingManager.useEffect"];
            }
        }
    }["BookingManager.useEffect"], [
        highlightedBookingId,
        groupedBookings,
        rowsPerPage,
        page
    ]);
    const handleOpenImageViewer = (urls, startIndex)=>{
        setViewerState({
            isOpen: true,
            urls,
            startIndex
        });
    };
    const handleUpdateStatus = async (bookingIds, status)=>{
        if (userProfile.role !== 'admin' && userProfile.role !== 'club_owner') {
            toast({
                title: 'Lỗi!',
                description: 'Bạn không có quyền thực hiện hành động này.',
                variant: 'destructive'
            });
            return;
        }
        try {
            const promises = bookingIds.map((id)=>supabase.from('bookings').update({
                    status
                }).eq('id', id));
            await Promise.all(promises);
            // If cancelling bookings, decrement the booking count
            if (status === 'Đã hủy') {
                // Get the club_id from the first booking to decrement counter
                const bookingsToCancel = allBookings === null || allBookings === void 0 ? void 0 : allBookings.filter((b)=>bookingIds.includes(b.id));
                if (bookingsToCancel && bookingsToCancel.length > 0) {
                    const clubId = bookingsToCancel[0].club_id;
                    try {
                        const { error: quotaError } = await supabase.rpc('decrement_booking_count', {
                            p_club_id: clubId
                        });
                        if (quotaError) {
                            console.error('Failed to decrement booking count:', quotaError);
                        // Don't fail the cancellation if quota tracking fails
                        }
                    } catch (quotaErr) {
                        console.error('Quota tracking error:', quotaErr);
                    }
                }
            }
            toast({
                title: 'Cập nhật thành công!',
                description: 'Đã đổi trạng thái cho các lịch đặt thành "'.concat(status, '".')
            });
            refetchBookings();
        } catch (error) {
            console.error(error);
            toast({
                title: 'Lỗi!',
                description: 'Không thể cập nhật một số trạng thái.',
                variant: 'destructive'
            });
        }
    };
    const handleDeleteBookings = async (bookingIds)=>{
        if (userProfile.role !== 'admin' && userProfile.role !== 'club_owner') {
            toast({
                title: 'Lỗi!',
                description: 'Bạn không có quyền thực hiện hành động này.',
                variant: 'destructive'
            });
            return;
        }
        try {
            const promises = bookingIds.map((id)=>supabase.from('bookings').update({
                    is_deleted: true
                }).eq('id', id));
            await Promise.all(promises);
            toast({
                title: 'Xóa thành công!',
                description: "Đã xóa các lịch đặt được chọn."
            });
            refetchBookings();
        } catch (error) {
            console.error(error);
            toast({
                title: 'Lỗi!',
                description: 'Không thể xóa một số lịch đặt.',
                variant: 'destructive'
            });
        }
    };
    const handleExportInvoice = async (group)=>{
        toast({
            title: 'Đang khởi tạo hóa đơn...',
            description: 'Vui lòng chờ trong giây lát.'
        });
        try {
            var _group_bookingIds_;
            const firstBooking = group.bookings[0];
            const { data: clubData } = await supabase.from('clubs').select('*').eq('id', firstBooking.club_id).single();
            const qrUrl = (clubData === null || clubData === void 0 ? void 0 : clubData.payment_qr_url) || '/ma-qr.JPG';
            const orderId = group.bookingGroupId || ((_group_bookingIds_ = group.bookingIds[0]) === null || _group_bookingIds_ === void 0 ? void 0 : _group_bookingIds_.slice(0, 8)) || '';
            const slotRows = [];
            Object.entries(group.slotsByDate).forEach((param)=>{
                let [date, slots] = param;
                const byCourtMap = {};
                slots.forEach((s)=>{
                    if (!byCourtMap[s.courtName]) byCourtMap[s.courtName] = [];
                    byCourtMap[s.courtName].push(s.time);
                });
                const parts = Object.entries(byCourtMap).map((param)=>{
                    let [courtName, times] = param;
                    const sorted = times.sort();
                    const from = sorted[0];
                    const lastTime = sorted[sorted.length - 1];
                    const [h, m] = lastTime.split(':').map(Number);
                    const totalMinutes = h * 60 + m + 30;
                    const endHour = Math.floor(totalMinutes / 60);
                    const endMinute = totalMinutes % 60;
                    const to = "".concat(String(endHour).padStart(2, '0'), ":").concat(String(endMinute).padStart(2, '0'));
                    return "".concat(from, " - ").concat(to, " (").concat(courtName, ")");
                });
                slotRows.push({
                    date: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$format$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(new Date(date + 'T00:00:00'), 'dd/MM/yyyy'),
                    details: parts.join(', ')
                });
            });
            const slotRowsHtml = slotRows.map((r, i)=>'\n                <tr style="border-bottom:1px solid #e5e7eb;">\n                    <td style="padding:8px 12px;text-align:center;">'.concat(i + 1, '</td>\n                    <td style="padding:8px 12px;">').concat(r.date, '</td>\n                    <td style="padding:8px 12px;">').concat(r.details, "</td>\n                </tr>\n            ")).join('');
            const invoiceHtml = '\n                <div id="invoice-render" style="width:800px;padding:40px;font-family:\'Segoe UI\',Arial,sans-serif;background:#fff;color:#1a1a1a;">\n                    <div style="text-align:center;margin-bottom:24px;">\n                        <h1 style="font-size:24px;font-weight:700;margin:0 0 4px;">HÓA ĐƠN ĐẶT SÂN</h1>\n                        <p style="font-size:16px;font-weight:600;margin:0 0 2px;">'.concat((clubData === null || clubData === void 0 ? void 0 : clubData.name) || firstBooking.club_name || '', "</p>\n                        ").concat((clubData === null || clubData === void 0 ? void 0 : clubData.address) ? '<p style="font-size:13px;color:#666;margin:0;">'.concat(clubData.address, "</p>") : '', "\n                        ").concat((clubData === null || clubData === void 0 ? void 0 : clubData.phone) ? '<p style="font-size:13px;color:#666;margin:0;">ĐT: '.concat(clubData.phone, "</p>") : '', '\n                    </div>\n                    <hr style="border:none;border-top:2px solid #2980b9;margin:16px 0;" />\n                    <div style="display:flex;justify-content:space-between;margin-bottom:16px;">\n                        <div>\n                            <p style="margin:4px 0;font-size:14px;"><strong>Mã đơn:</strong> ').concat(orderId, '</p>\n                            <p style="margin:4px 0;font-size:14px;"><strong>Khách hàng:</strong> ').concat(group.name, '</p>\n                            <p style="margin:4px 0;font-size:14px;"><strong>SĐT:</strong> ').concat(group.phone, '</p>\n                        </div>\n                        <div style="text-align:right;">\n                            <p style="margin:4px 0;font-size:14px;"><strong>Ngày tạo:</strong> ').concat(group.latestCreatedAt ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$format$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(new Date(group.latestCreatedAt), 'HH:mm dd/MM/yyyy') : '', '</p>\n                            <p style="margin:4px 0;font-size:14px;"><strong>Trạng thái:</strong> ').concat(group.statusSummary, '</p>\n                        </div>\n                    </div>\n                    <table style="width:100%;border-collapse:collapse;margin-bottom:16px;">\n                        <thead>\n                            <tr style="background:#2980b9;color:#fff;">\n                                <th style="padding:10px 12px;text-align:center;width:50px;">STT</th>\n                                <th style="padding:10px 12px;text-align:left;">Ngày</th>\n                                <th style="padding:10px 12px;text-align:left;">Ca đặt</th>\n                            </tr>\n                        </thead>\n                        <tbody>').concat(slotRowsHtml, '</tbody>\n                    </table>\n                    <div style="text-align:right;margin-bottom:20px;">\n                        <p style="font-size:18px;font-weight:700;color:#2980b9;margin:0;">Tổng tiền: ').concat(new Intl.NumberFormat('vi-VN').format(group.totalPrice), ' VNĐ</p>\n                    </div>\n                    <div style="text-align:center;margin-top:16px;">\n                        <p style="font-size:13px;color:#666;margin:0 0 8px;">Quét mã QR để thanh toán</p>\n                        <img src="').concat(qrUrl, '" style="width:180px;height:180px;object-fit:contain;" crossorigin="anonymous" />\n                    </div>\n                    <hr style="border:none;border-top:1px solid #e5e7eb;margin:20px 0 8px;" />\n                    <p style="text-align:center;font-size:12px;color:#999;margin:0;">Cảm ơn quý khách đã sử dụng dịch vụ!</p>\n                </div>\n            ');
            const container = document.createElement('div');
            container.style.position = 'fixed';
            container.style.left = '-9999px';
            container.style.top = '0';
            container.innerHTML = invoiceHtml;
            document.body.appendChild(container);
            const invoiceEl = container.querySelector('#invoice-render');
            const canvas = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$html2canvas$2f$dist$2f$html2canvas$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(invoiceEl, {
                scale: 2,
                useCORS: true,
                allowTaint: true
            });
            document.body.removeChild(container);
            const imgData = canvas.toDataURL('image/png');
            const pdf = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jspdf$2f$dist$2f$jspdf$2e$es$2e$min$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]('p', 'mm', 'a4');
            const pdfWidth = pdf.internal.pageSize.getWidth();
            const pdfHeight = canvas.height * pdfWidth / canvas.width;
            pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
            pdf.save("hoa-don-".concat(orderId || 'booking', ".pdf"));
            toast({
                title: 'Thành công',
                description: 'Đã tạo hóa đơn PDF.'
            });
        } catch (error) {
            console.error(error);
            toast({
                title: 'Lỗi',
                description: 'Không thể tạo hóa đơn.',
                variant: 'destructive'
            });
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Card"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardHeader"], {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col gap-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardTitle"], {
                                            children: "Quản lý Lịch đặt"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                            lineNumber: 363,
                                            columnNumber: 26
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardDescription"], {
                                            children: "Xem, xác nhận hoặc hủy các lịch đặt sân."
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                            lineNumber: 363,
                                            columnNumber: 65
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                    lineNumber: 363,
                                    columnNumber: 21
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex flex-col sm:flex-row flex-wrap gap-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Select"], {
                                            value: statusFilter,
                                            onValueChange: setStatusFilter,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectTrigger"], {
                                                    className: "w-full sm:w-[180px]",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectValue"], {
                                                        placeholder: "Trạng thái"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                        lineNumber: 365,
                                                        columnNumber: 133
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                    lineNumber: 365,
                                                    columnNumber: 86
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectContent"], {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectItem"], {
                                                            value: "all",
                                                            children: "Tất cả"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                            lineNumber: 365,
                                                            columnNumber: 204
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectItem"], {
                                                            value: "Chờ xác nhận",
                                                            children: "Chờ xác nhận"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                            lineNumber: 365,
                                                            columnNumber: 247
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectItem"], {
                                                            value: "Đã xác nhận",
                                                            children: "Đã xác nhận"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                            lineNumber: 365,
                                                            columnNumber: 305
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectItem"], {
                                                            value: "Đã hủy",
                                                            children: "Đã hủy"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                            lineNumber: 365,
                                                            columnNumber: 361
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                    lineNumber: 365,
                                                    columnNumber: 189
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                            lineNumber: 365,
                                            columnNumber: 25
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"], {
                                            placeholder: "Tìm theo tên hoặc SĐT...",
                                            value: searchTerm,
                                            onChange: (e)=>setSearchTerm(e.target.value),
                                            className: "w-full sm:w-[200px]"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                            lineNumber: 366,
                                            columnNumber: 25
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ant$2d$design$2f$nextjs$2d$registry$2f$es$2f$AntdRegistry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AntdRegistry$3e$__["AntdRegistry"], {
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$antd$2f$es$2f$config$2d$provider$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__ConfigProvider$3e$__["ConfigProvider"], {
                                                locale: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$antd$2f$locale$2f$vi_VN$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$antd$2f$es$2f$date$2d$picker$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DatePicker$3e$__["DatePicker"].RangePicker, {
                                                    value: dateRange,
                                                    onChange: (dates)=>setDateRange(dates),
                                                    format: "DD/MM/YYYY",
                                                    placeholder: [
                                                        'Từ ngày',
                                                        'Đến ngày'
                                                    ],
                                                    className: "w-full sm:w-auto h-10",
                                                    allowClear: true,
                                                    variant: "outlined"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                    lineNumber: 368,
                                                    columnNumber: 29
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                lineNumber: 367,
                                                columnNumber: 39
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                            lineNumber: 367,
                                            columnNumber: 25
                                        }, this),
                                        userProfile.role === 'admin' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Select"], {
                                            value: selectedOwnerId,
                                            onValueChange: setSelectedOwnerId,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectTrigger"], {
                                                    className: "w-full sm:w-[200px]",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectValue"], {
                                                        placeholder: "Lọc theo chủ club"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                        lineNumber: 371,
                                                        columnNumber: 143
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                    lineNumber: 371,
                                                    columnNumber: 96
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectContent"], {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectItem"], {
                                                            value: "all",
                                                            children: "Tất cả chủ club"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                            lineNumber: 371,
                                                            columnNumber: 221
                                                        }, this),
                                                        owners === null || owners === void 0 ? void 0 : owners.map((o)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectItem"], {
                                                                value: o.id,
                                                                children: o.email
                                                            }, o.id, false, {
                                                                fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                                lineNumber: 371,
                                                                columnNumber: 291
                                                            }, this))
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                    lineNumber: 371,
                                                    columnNumber: 206
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                            lineNumber: 371,
                                            columnNumber: 29
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Select"], {
                                            value: selectedClubId,
                                            onValueChange: setSelectedClubId,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectTrigger"], {
                                                    className: "w-full sm:w-[200px]",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectValue"], {
                                                        placeholder: "Lọc theo club"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                        lineNumber: 373,
                                                        columnNumber: 137
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                    lineNumber: 373,
                                                    columnNumber: 90
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectContent"], {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectItem"], {
                                                            value: "all",
                                                            children: "Tất cả club"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                            lineNumber: 373,
                                                            columnNumber: 211
                                                        }, this),
                                                        allClubs === null || allClubs === void 0 ? void 0 : allClubs.map((c)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectItem"], {
                                                                value: c.id,
                                                                children: c.name
                                                            }, c.id, false, {
                                                                fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                                lineNumber: 373,
                                                                columnNumber: 279
                                                            }, this))
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                    lineNumber: 373,
                                                    columnNumber: 196
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                            lineNumber: 373,
                                            columnNumber: 25
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                    lineNumber: 364,
                                    columnNumber: 21
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                            lineNumber: 362,
                            columnNumber: 17
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                        lineNumber: 361,
                        columnNumber: 13
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardContent"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-sm text-muted-foreground mb-4",
                                children: [
                                    "Tổng: ",
                                    groupedBookings.length,
                                    " đơn đặt | Trang ",
                                    page,
                                    "/",
                                    pageCount || 1
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                lineNumber: 378,
                                columnNumber: 17
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Table"], {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableHeader"], {
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableRow"], {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableHead"], {
                                                    children: "Mã đơn"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                    lineNumber: 380,
                                                    columnNumber: 44
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableHead"], {
                                                    children: "Khách hàng"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                    lineNumber: 380,
                                                    columnNumber: 73
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableHead"], {
                                                    children: "Ca đặt"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                    lineNumber: 380,
                                                    columnNumber: 106
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableHead"], {
                                                    children: "Bằng chứng CK"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                    lineNumber: 380,
                                                    columnNumber: 135
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableHead"], {
                                                    children: "Tổng tiền"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                    lineNumber: 380,
                                                    columnNumber: 171
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableHead"], {
                                                    children: "Trạng thái"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                    lineNumber: 380,
                                                    columnNumber: 203
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableHead"], {
                                                    children: "Ngày tạo"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                    lineNumber: 380,
                                                    columnNumber: 236
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableHead"], {
                                                    className: "text-right",
                                                    children: "Hành động"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                    lineNumber: 380,
                                                    columnNumber: 267
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                            lineNumber: 380,
                                            columnNumber: 34
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                        lineNumber: 380,
                                        columnNumber: 21
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableBody"], {
                                        children: [
                                            loading && Array.from({
                                                length: 3
                                            }).map((_, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableRow"], {
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableCell"], {
                                                        colSpan: 8,
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$skeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Skeleton"], {
                                                            className: "h-10 w-full"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                            lineNumber: 382,
                                                            columnNumber: 119
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                        lineNumber: 382,
                                                        columnNumber: 96
                                                    }, this)
                                                }, i, false, {
                                                    fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                    lineNumber: 382,
                                                    columnNumber: 78
                                                }, this)),
                                            paginatedBookings.map((group)=>{
                                                var _group_bookingIds_;
                                                const isHighlighted = highlightedBookingId && group.bookingIds.includes(highlightedBookingId);
                                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableRow"], {
                                                    id: "booking-".concat(group.id),
                                                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])(isHighlighted && "bg-primary/10 animate-pulse"),
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableCell"], {
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "text-xs font-mono text-muted-foreground",
                                                                children: group.bookingGroupId || ((_group_bookingIds_ = group.bookingIds[0]) === null || _group_bookingIds_ === void 0 ? void 0 : _group_bookingIds_.slice(0, 8)) || '—'
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                                lineNumber: 387,
                                                                columnNumber: 48
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                            lineNumber: 387,
                                                            columnNumber: 37
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableCell"], {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "font-medium",
                                                                    children: group.name
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                                    lineNumber: 388,
                                                                    columnNumber: 48
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "text-xs text-muted-foreground",
                                                                    children: group.phone
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                                    lineNumber: 388,
                                                                    columnNumber: 95
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                            lineNumber: 388,
                                                            columnNumber: 37
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableCell"], {
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "text-xs space-y-1.5",
                                                                children: Object.entries(group.slotsByDate).map((param)=>{
                                                                    let [date, slots] = param;
                                                                    const byCourtMap = {};
                                                                    slots.forEach((s)=>{
                                                                        if (!byCourtMap[s.courtName]) byCourtMap[s.courtName] = [];
                                                                        byCourtMap[s.courtName].push(s.time);
                                                                    });
                                                                    const ranges = Object.entries(byCourtMap).map((param)=>{
                                                                        let [courtName, times] = param;
                                                                        const sorted = times.sort();
                                                                        const from = sorted[0];
                                                                        const lastTime = sorted[sorted.length - 1];
                                                                        const [h, m] = lastTime.split(':').map(Number);
                                                                        const totalMinutes = h * 60 + m + 30;
                                                                        const endHour = Math.floor(totalMinutes / 60);
                                                                        const endMinute = totalMinutes % 60;
                                                                        const to = "".concat(String(endHour).padStart(2, '0'), ":").concat(String(endMinute).padStart(2, '0'));
                                                                        return {
                                                                            from,
                                                                            to,
                                                                            courtName
                                                                        };
                                                                    });
                                                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        children: [
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                className: "font-medium",
                                                                                children: [
                                                                                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$format$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(new Date(date + 'T00:00:00'), 'dd/MM/yyyy'),
                                                                                    ":"
                                                                                ]
                                                                            }, void 0, true, {
                                                                                fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                                                lineNumber: 410,
                                                                                columnNumber: 57
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                className: "flex flex-wrap gap-1 mt-0.5",
                                                                                children: ranges.map((r, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                        className: "inline-flex items-center rounded-full bg-muted px-2 py-0.5 text-[11px] font-medium",
                                                                                        children: [
                                                                                            r.from,
                                                                                            "-",
                                                                                            r.to,
                                                                                            " (",
                                                                                            r.courtName,
                                                                                            ")"
                                                                                        ]
                                                                                    }, i, true, {
                                                                                        fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                                                        lineNumber: 413,
                                                                                        columnNumber: 65
                                                                                    }, this))
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                                                lineNumber: 411,
                                                                                columnNumber: 57
                                                                            }, this)
                                                                        ]
                                                                    }, date, true, {
                                                                        fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                                        lineNumber: 409,
                                                                        columnNumber: 53
                                                                    }, this);
                                                                })
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                                lineNumber: 390,
                                                                columnNumber: 41
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                            lineNumber: 389,
                                                            columnNumber: 37
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableCell"], {
                                                            children: group.paymentProofImageUrls.length > 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                                                variant: "link",
                                                                size: "sm",
                                                                className: "p-0 h-auto text-xs",
                                                                onClick: ()=>handleOpenImageViewer(group.paymentProofImageUrls, 0),
                                                                children: [
                                                                    "Xem ảnh (",
                                                                    group.paymentProofImageUrls.length,
                                                                    ")"
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                                lineNumber: 425,
                                                                columnNumber: 45
                                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "text-xs text-muted-foreground",
                                                                children: "—"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                                lineNumber: 426,
                                                                columnNumber: 45
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                            lineNumber: 423,
                                                            columnNumber: 37
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableCell"], {
                                                            className: "font-medium",
                                                            children: [
                                                                new Intl.NumberFormat('vi-VN').format(group.totalPrice),
                                                                "đ"
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                            lineNumber: 428,
                                                            columnNumber: 37
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableCell"], {
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Badge"], {
                                                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])(group.statusSummary.includes('Đã xác nhận') ? 'bg-green-500 text-white border-green-500 hover:bg-green-500/80' : group.statusSummary.includes('Chờ') ? 'bg-gray-400 text-white border-gray-400 hover:bg-gray-400/80' : 'bg-red-500 text-white border-red-500 hover:bg-red-500/80'),
                                                                children: group.statusSummary
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                                lineNumber: 429,
                                                                columnNumber: 48
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                            lineNumber: 429,
                                                            columnNumber: 37
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableCell"], {
                                                            className: "text-xs text-muted-foreground",
                                                            children: group.latestCreatedAt ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$format$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(new Date(group.latestCreatedAt), 'HH:mm dd/MM/yyyy', {
                                                                locale: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$locale$2f$vi$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["vi"]
                                                            }) : '...'
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                            lineNumber: 434,
                                                            columnNumber: 37
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableCell"], {
                                                            className: "text-right",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenu"], {
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuTrigger"], {
                                                                        asChild: true,
                                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                                                            variant: "ghost",
                                                                            className: "h-8 w-8 p-0",
                                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$ellipsis$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MoreHorizontal$3e$__["MoreHorizontal"], {
                                                                                className: "h-4 w-4"
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                                                lineNumber: 436,
                                                                                columnNumber: 132
                                                                            }, this)
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                                            lineNumber: 436,
                                                                            columnNumber: 84
                                                                        }, this)
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                                        lineNumber: 436,
                                                                        columnNumber: 55
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuContent"], {
                                                                        align: "end",
                                                                        children: [
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuItem"], {
                                                                                onClick: ()=>handleUpdateStatus(group.bookingIds, 'Đã xác nhận'),
                                                                                children: [
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle2$3e$__["CheckCircle2"], {
                                                                                        className: "mr-2 h-4 w-4"
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                                                        lineNumber: 438,
                                                                                        columnNumber: 135
                                                                                    }, this),
                                                                                    "Xác nhận"
                                                                                ]
                                                                            }, void 0, true, {
                                                                                fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                                                lineNumber: 438,
                                                                                columnNumber: 49
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuItem"], {
                                                                                onClick: ()=>handleUpdateStatus(group.bookingIds, 'Đã hủy'),
                                                                                className: "text-destructive",
                                                                                children: "Hủy đặt"
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                                                lineNumber: 439,
                                                                                columnNumber: 49
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuSeparator"], {}, void 0, false, {
                                                                                fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                                                lineNumber: 440,
                                                                                columnNumber: 49
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuItem"], {
                                                                                onClick: ()=>handleExportInvoice(group),
                                                                                children: [
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$file$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FileDown$3e$__["FileDown"], {
                                                                                        className: "mr-2 h-4 w-4"
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                                                        lineNumber: 441,
                                                                                        columnNumber: 110
                                                                                    }, this),
                                                                                    "Xuất hóa đơn"
                                                                                ]
                                                                            }, void 0, true, {
                                                                                fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                                                lineNumber: 441,
                                                                                columnNumber: 49
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuSeparator"], {}, void 0, false, {
                                                                                fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                                                lineNumber: 442,
                                                                                columnNumber: 49
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuItem"], {
                                                                                onClick: ()=>handleDeleteBookings(group.bookingIds),
                                                                                className: "text-destructive",
                                                                                children: [
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2d$2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash2$3e$__["Trash2"], {
                                                                                        className: "mr-2 h-4 w-4"
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                                                        lineNumber: 443,
                                                                                        columnNumber: 151
                                                                                    }, this),
                                                                                    "Xóa"
                                                                                ]
                                                                            }, void 0, true, {
                                                                                fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                                                lineNumber: 443,
                                                                                columnNumber: 49
                                                                            }, this)
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                                        lineNumber: 437,
                                                                        columnNumber: 45
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                                lineNumber: 436,
                                                                columnNumber: 41
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                            lineNumber: 435,
                                                            columnNumber: 37
                                                        }, this)
                                                    ]
                                                }, group.id, true, {
                                                    fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                    lineNumber: 386,
                                                    columnNumber: 33
                                                }, this);
                                            }),
                                            !loading && groupedBookings.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableRow"], {
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableCell"], {
                                                    colSpan: 8,
                                                    className: "h-24 text-center",
                                                    children: "Không có lịch đặt nào."
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                    lineNumber: 450,
                                                    columnNumber: 81
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                                lineNumber: 450,
                                                columnNumber: 71
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                        lineNumber: 381,
                                        columnNumber: 21
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                lineNumber: 379,
                                columnNumber: 17
                            }, this),
                            pageCount > 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center justify-end gap-2 mt-4",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                        variant: "outline",
                                        size: "sm",
                                        onClick: ()=>setPage((p)=>Math.max(1, p - 1)),
                                        disabled: page === 1,
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeft$3e$__["ChevronLeft"], {
                                            className: "h-4 w-4"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                            lineNumber: 455,
                                            columnNumber: 132
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                        lineNumber: 455,
                                        columnNumber: 25
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-sm",
                                        children: [
                                            page,
                                            " / ",
                                            pageCount
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                        lineNumber: 456,
                                        columnNumber: 25
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                        variant: "outline",
                                        size: "sm",
                                        onClick: ()=>setPage((p)=>Math.min(pageCount, p + 1)),
                                        disabled: page === pageCount,
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__["ChevronRight"], {
                                            className: "h-4 w-4"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                            lineNumber: 457,
                                            columnNumber: 148
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                        lineNumber: 457,
                                        columnNumber: 25
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                                lineNumber: 454,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                        lineNumber: 377,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                lineNumber: 360,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ImageViewer, {
                imageUrls: viewerState.urls,
                startIndex: viewerState.startIndex,
                isOpen: viewerState.isOpen,
                onClose: ()=>setViewerState({
                        ...viewerState,
                        isOpen: false
                    })
            }, void 0, false, {
                fileName: "[project]/src/app/admin/_components/booking-manager.tsx",
                lineNumber: 462,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true);
}
_s1(BookingManager, "fFr9Aejj5TyEeI+SQwxVuCPBhag=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$supabase$2f$provider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSupabase"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$use$2d$toast$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useToast"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$supabase$2f$hooks$2f$use$2d$query$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSupabaseQuery"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$supabase$2f$hooks$2f$use$2d$query$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSupabaseQuery"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$supabase$2f$hooks$2f$use$2d$query$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSupabaseQuery"]
    ];
});
_c1 = BookingManager;
var _c, _c1;
__turbopack_context__.k.register(_c, "ImageViewer");
__turbopack_context__.k.register(_c1, "BookingManager");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_app_admin__components_booking-manager_tsx_23b0e729._.js.map