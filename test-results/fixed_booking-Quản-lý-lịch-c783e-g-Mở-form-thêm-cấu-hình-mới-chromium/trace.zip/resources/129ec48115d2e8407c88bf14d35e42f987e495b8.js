(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/@rc-component/form/es/FieldContext.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "HOOK_MARK",
    ()=>HOOK_MARK,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$warning$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/util/es/warning.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
;
const HOOK_MARK = 'RC_FORM_INTERNAL_HOOKS';
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const warningFunc = ()=>{
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$warning$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(false, 'Can not find FormContext. Please make sure you wrap Field under Form.');
};
const Context = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"]({
    getFieldValue: warningFunc,
    getFieldsValue: warningFunc,
    getFieldError: warningFunc,
    getFieldWarning: warningFunc,
    getFieldsError: warningFunc,
    isFieldsTouched: warningFunc,
    isFieldTouched: warningFunc,
    isFieldValidating: warningFunc,
    isFieldsValidating: warningFunc,
    resetFields: warningFunc,
    setFields: warningFunc,
    setFieldValue: warningFunc,
    setFieldsValue: warningFunc,
    validateFields: warningFunc,
    submit: warningFunc,
    getInternalHooks: ()=>{
        warningFunc();
        return {
            dispatch: warningFunc,
            initEntityValue: warningFunc,
            registerField: warningFunc,
            useSubscribe: warningFunc,
            setInitialValues: warningFunc,
            destroyForm: warningFunc,
            setCallbacks: warningFunc,
            registerWatch: warningFunc,
            getFields: warningFunc,
            setValidateMessages: warningFunc,
            setPreserve: warningFunc,
            getInitialValue: warningFunc
        };
    }
});
const __TURBOPACK__default__export__ = Context;
}),
"[project]/node_modules/@rc-component/form/es/ListContext.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
const ListContext = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"](null);
const __TURBOPACK__default__export__ = ListContext;
}),
"[project]/node_modules/@rc-component/form/es/utils/typeUtil.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "isFormInstance",
    ()=>isFormInstance,
    "toArray",
    ()=>toArray
]);
function toArray(value) {
    if (value === undefined || value === null) {
        return [];
    }
    return Array.isArray(value) ? value : [
        value
    ];
}
function isFormInstance(form) {
    return form && !!form._init;
}
}),
"[project]/node_modules/@rc-component/form/es/utils/messages.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "defaultValidateMessages",
    ()=>defaultValidateMessages
]);
const typeTemplate = "'${name}' is not a valid ${type}";
const defaultValidateMessages = {
    default: "Validation error on field '${name}'",
    required: "'${name}' is required",
    enum: "'${name}' must be one of [${enum}]",
    whitespace: "'${name}' cannot be empty",
    date: {
        format: "'${name}' is invalid for format date",
        parse: "'${name}' could not be parsed as date",
        invalid: "'${name}' is invalid date"
    },
    types: {
        string: typeTemplate,
        method: typeTemplate,
        array: typeTemplate,
        object: typeTemplate,
        number: typeTemplate,
        date: typeTemplate,
        boolean: typeTemplate,
        integer: typeTemplate,
        float: typeTemplate,
        regexp: typeTemplate,
        email: typeTemplate,
        tel: typeTemplate,
        url: typeTemplate,
        hex: typeTemplate
    },
    string: {
        len: "'${name}' must be exactly ${len} characters",
        min: "'${name}' must be at least ${min} characters",
        max: "'${name}' cannot be longer than ${max} characters",
        range: "'${name}' must be between ${min} and ${max} characters"
    },
    number: {
        len: "'${name}' must equal ${len}",
        min: "'${name}' cannot be less than ${min}",
        max: "'${name}' cannot be greater than ${max}",
        range: "'${name}' must be between ${min} and ${max}"
    },
    array: {
        len: "'${name}' must be exactly ${len} in length",
        min: "'${name}' cannot be less than ${min} in length",
        max: "'${name}' cannot be greater than ${max} in length",
        range: "'${name}' must be between ${min} and ${max} in length"
    },
    pattern: {
        mismatch: "'${name}' does not match pattern ${pattern}"
    }
};
}),
"[project]/node_modules/@rc-component/form/es/utils/validateUtil.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "validateRules",
    ()=>validateRules
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$async$2d$validator$2f$es$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/async-validator/es/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$warning$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/util/es/warning.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$messages$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/form/es/utils/messages.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$utils$2f$set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/util/es/utils/set.js [app-client] (ecmascript)");
;
;
;
;
;
// Remove incorrect original ts define
const AsyncValidator = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$async$2d$validator$2f$es$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"];
/**
 * Replace with template.
 *   `I'm ${name}` + { name: 'bamboo' } = I'm bamboo
 */ function replaceMessage(template, kv) {
    return template.replace(/\\?\$\{\w+\}/g, (str)=>{
        if (str.startsWith('\\')) {
            return str.slice(1);
        }
        const key = str.slice(2, -1);
        return kv[key];
    });
}
const CODE_LOGIC_ERROR = 'CODE_LOGIC_ERROR';
async function validateRule(name, value, rule, options, messageVariables) {
    const cloneRule = {
        ...rule
    };
    // Bug of `async-validator`
    // https://github.com/react-component/field-form/issues/316
    // https://github.com/react-component/field-form/issues/313
    delete cloneRule.ruleIndex;
    // https://github.com/ant-design/ant-design/issues/40497#issuecomment-1422282378
    AsyncValidator.warning = ()=>void 0;
    if (cloneRule.validator) {
        const originValidator = cloneRule.validator;
        cloneRule.validator = function() {
            for(var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++){
                args[_key] = arguments[_key];
            }
            try {
                return originValidator(...args);
            } catch (error) {
                console.error(error);
                return Promise.reject(CODE_LOGIC_ERROR);
            }
        };
    }
    // We should special handle array validate
    let subRuleField = null;
    if (cloneRule && cloneRule.type === 'array' && cloneRule.defaultField) {
        subRuleField = cloneRule.defaultField;
        delete cloneRule.defaultField;
    }
    const validator = new AsyncValidator({
        [name]: [
            cloneRule
        ]
    });
    const messages = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$utils$2f$set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["merge"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$messages$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultValidateMessages"], options.validateMessages);
    validator.messages(messages);
    let result = [];
    try {
        await Promise.resolve(validator.validate({
            [name]: value
        }, {
            ...options
        }));
    } catch (errObj) {
        if (errObj.errors) {
            result = errObj.errors.map((param, index)=>{
                let { message } = param;
                const mergedMessage = message === CODE_LOGIC_ERROR ? messages.default : message;
                return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isValidElement"](mergedMessage) ? /*#__PURE__*/ // Wrap ReactNode with `key`
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cloneElement"](mergedMessage, {
                    key: "error_".concat(index)
                }) : mergedMessage;
            });
        }
    }
    if (!result.length && subRuleField && Array.isArray(value) && value.length > 0) {
        const subResults = await Promise.all(value.map((subValue, i)=>validateRule("".concat(name, ".").concat(i), subValue, subRuleField, options, messageVariables)));
        return subResults.reduce((prev, errors)=>[
                ...prev,
                ...errors
            ], []);
    }
    // Replace message with variables
    const kv = {
        ...rule,
        name,
        enum: (rule.enum || []).join(', '),
        ...messageVariables
    };
    const fillVariableResult = result.map((error)=>{
        if (typeof error === 'string') {
            return replaceMessage(error, kv);
        }
        return error;
    });
    return fillVariableResult;
}
function validateRules(namePath, value, rules, options, validateFirst, messageVariables) {
    const name = namePath.join('.');
    // Fill rule with context
    const filledRules = rules.map((currentRule, ruleIndex)=>{
        const originValidatorFunc = currentRule.validator;
        const cloneRule = {
            ...currentRule,
            ruleIndex
        };
        // Replace validator if needed
        if (originValidatorFunc) {
            cloneRule.validator = (rule, val, callback)=>{
                let hasPromise = false;
                // Wrap callback only accept when promise not provided
                const wrappedCallback = function() {
                    for(var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++){
                        args[_key] = arguments[_key];
                    }
                    // Wait a tick to make sure return type is a promise
                    Promise.resolve().then(()=>{
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$warning$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(!hasPromise, 'Your validator function has already return a promise. `callback` will be ignored.');
                        if (!hasPromise) {
                            callback(...args);
                        }
                    });
                };
                // Get promise
                const promise = originValidatorFunc(rule, val, wrappedCallback);
                hasPromise = promise && typeof promise.then === 'function' && typeof promise.catch === 'function';
                /**
         * 1. Use promise as the first priority.
         * 2. If promise not exist, use callback with warning instead
         */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$warning$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(hasPromise, '`callback` is deprecated. Please return a promise instead.');
                if (hasPromise) {
                    promise.then(()=>{
                        callback();
                    }).catch((err)=>{
                        callback(err || ' ');
                    });
                }
            };
        }
        return cloneRule;
    }).sort((param, param1)=>{
        let { warningOnly: w1, ruleIndex: i1 } = param, { warningOnly: w2, ruleIndex: i2 } = param1;
        if (!!w1 === !!w2) {
            // Let keep origin order
            return i1 - i2;
        }
        if (w1) {
            return 1;
        }
        return -1;
    });
    // Do validate rules
    let summaryPromise;
    if (validateFirst === true) {
        // >>>>> Validate by serialization
        summaryPromise = new Promise(async (resolve, reject)=>{
            /* eslint-disable no-await-in-loop */ for(let i = 0; i < filledRules.length; i += 1){
                const rule = filledRules[i];
                const errors = await validateRule(name, value, rule, options, messageVariables);
                if (errors.length) {
                    reject([
                        {
                            errors,
                            rule
                        }
                    ]);
                    return;
                }
            }
            /* eslint-enable */ resolve([]);
        });
    } else {
        // >>>>> Validate by parallel
        const rulePromises = filledRules.map((rule)=>validateRule(name, value, rule, options, messageVariables).then((errors)=>({
                    errors,
                    rule
                })));
        summaryPromise = (validateFirst ? finishOnFirstFailed(rulePromises) : finishOnAllFailed(rulePromises)).then((errors)=>{
            // Always change to rejection for Field to catch
            return Promise.reject(errors);
        });
    }
    // Internal catch error to avoid console error log.
    summaryPromise.catch((e)=>e);
    return summaryPromise;
}
async function finishOnAllFailed(rulePromises) {
    return Promise.all(rulePromises).then((errorsList)=>{
        const errors = [].concat(...errorsList);
        return errors;
    });
}
async function finishOnFirstFailed(rulePromises) {
    let count = 0;
    return new Promise((resolve)=>{
        rulePromises.forEach((promise)=>{
            promise.then((ruleError)=>{
                if (ruleError.errors.length) {
                    resolve([
                        ruleError
                    ]);
                }
                count += 1;
                if (count === rulePromises.length) {
                    resolve([]);
                }
            });
        });
    });
}
}),
"[project]/node_modules/@rc-component/form/es/utils/valueUtil.js [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cloneByNamePathList",
    ()=>cloneByNamePathList,
    "containsNamePath",
    ()=>containsNamePath,
    "defaultGetValueFromEvent",
    ()=>defaultGetValueFromEvent,
    "getNamePath",
    ()=>getNamePath,
    "isSimilar",
    ()=>isSimilar,
    "matchNamePath",
    ()=>matchNamePath,
    "move",
    ()=>move
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$utils$2f$get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/util/es/utils/get.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$utils$2f$set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/util/es/utils/set.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$typeUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/form/es/utils/typeUtil.js [app-client] (ecmascript)");
;
;
;
;
function getNamePath(path) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$typeUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toArray"])(path);
}
function cloneByNamePathList(store, namePathList) {
    let newStore = {};
    namePathList.forEach((namePath)=>{
        const value = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$utils$2f$get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(store, namePath);
        newStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$utils$2f$set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(newStore, namePath, value);
    });
    return newStore;
}
function containsNamePath(namePathList, namePath) {
    let partialMatch = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : false;
    return namePathList && namePathList.some((path)=>matchNamePath(namePath, path, partialMatch));
}
function matchNamePath(namePath, subNamePath) {
    let partialMatch = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : false;
    if (!namePath || !subNamePath) {
        return false;
    }
    if (!partialMatch && namePath.length !== subNamePath.length) {
        return false;
    }
    return subNamePath.every((nameUnit, i)=>namePath[i] === nameUnit);
}
function isSimilar(source, target) {
    if (source === target) {
        return true;
    }
    if (!source && target || source && !target) {
        return false;
    }
    if (!source || !target || typeof source !== 'object' || typeof target !== 'object') {
        return false;
    }
    const sourceKeys = Object.keys(source);
    const targetKeys = Object.keys(target);
    const keys = new Set([
        ...sourceKeys,
        ...targetKeys
    ]);
    return [
        ...keys
    ].every((key)=>{
        const sourceValue = source[key];
        const targetValue = target[key];
        if (typeof sourceValue === 'function' && typeof targetValue === 'function') {
            return true;
        }
        return sourceValue === targetValue;
    });
}
function defaultGetValueFromEvent(valuePropName) {
    for(var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++){
        args[_key - 1] = arguments[_key];
    }
    const event = args[0];
    if (event && event.target && typeof event.target === 'object' && valuePropName in event.target) {
        return event.target[valuePropName];
    }
    return event;
}
function move(array, moveIndex, toIndex) {
    const { length } = array;
    if (moveIndex < 0 || moveIndex >= length || toIndex < 0 || toIndex >= length) {
        return array;
    }
    const item = array[moveIndex];
    const diff = moveIndex - toIndex;
    if (diff > 0) {
        // move left
        return [
            ...array.slice(0, toIndex),
            item,
            ...array.slice(toIndex, moveIndex),
            ...array.slice(moveIndex + 1, length)
        ];
    }
    if (diff < 0) {
        // move right
        return [
            ...array.slice(0, moveIndex),
            ...array.slice(moveIndex + 1, toIndex + 1),
            item,
            ...array.slice(toIndex + 1, length)
        ];
    }
    return array;
}
}),
"[project]/node_modules/@rc-component/form/es/Field.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@swc/helpers/esm/_define_property.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$Children$2f$toArray$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/util/es/Children/toArray.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$isEqual$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/util/es/isEqual.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$warning$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/util/es/warning.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$FieldContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/form/es/FieldContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$ListContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/form/es/ListContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$typeUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/form/es/utils/typeUtil.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$validateUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/form/es/utils/validateUtil.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$valueUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/form/es/utils/valueUtil.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$utils$2f$get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__getValue$3e$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/util/es/utils/get.js [app-client] (ecmascript) <export default as getValue>");
;
function _extends() {
    _extends = ("TURBOPACK compile-time truthy", 1) ? Object.assign.bind() : "TURBOPACK unreachable";
    return _extends.apply(this, arguments);
}
;
;
;
;
;
;
;
;
;
const EMPTY_ERRORS = [];
const EMPTY_WARNINGS = [];
function requireUpdate(shouldUpdate, prev, next, prevValue, nextValue, info) {
    if (typeof shouldUpdate === 'function') {
        return shouldUpdate(prev, next, 'source' in info ? {
            source: info.source
        } : {});
    }
    return prevValue !== nextValue;
}
var _React_Component;
// eslint-disable-next-line @typescript-eslint/consistent-indexed-object-style
// We use Class instead of Hooks here since it will cost much code by using Hooks.
class Field extends (_React_Component = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Component"]) {
    componentDidMount() {
        const { shouldUpdate, fieldContext } = this.props;
        this.mounted = true;
        // Register on init
        if (fieldContext) {
            const { getInternalHooks } = fieldContext;
            const { registerField } = getInternalHooks(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$FieldContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HOOK_MARK"]);
            this.cancelRegisterFunc = registerField(this);
        }
        // One more render for component in case fields not ready
        if (shouldUpdate === true) {
            this.reRender();
        }
    }
    componentWillUnmount() {
        this.cancelRegister();
        this.triggerMetaEvent(true);
        this.mounted = false;
    }
    reRender() {
        if (!this.mounted) return;
        this.forceUpdate();
    }
    render() {
        const { resetCount } = this.state;
        const { children } = this.props;
        const { child, isFunction } = this.getOnlyChild(children);
        // Not need to `cloneElement` since user can handle this in render function self
        let returnChildNode;
        if (isFunction) {
            returnChildNode = child;
        } else if (/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isValidElement"](child)) {
            returnChildNode = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cloneElement"](child, this.getControlled(child.props));
        } else {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$warning$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(!child, '`children` of Field is not validate ReactElement.');
            returnChildNode = child;
        }
        return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            key: resetCount
        }, returnChildNode);
    }
    // ============================== Subscriptions ==============================
    constructor(props){
        var _this;
        super(props), _this = this, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "state", {
            resetCount: 0
        }), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "cancelRegisterFunc", null), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "mounted", false), /**
   * Follow state should not management in State since it will async update by React.
   * This makes first render of form can not get correct state value.
   */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "touched", false), /**
   * Mark when touched & validated. Currently only used for `dependencies`.
   * Note that we do not think field with `initialValue` is dirty
   * but this will be by `isFieldDirty` func.
   */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "dirty", false), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "validatePromise", void 0), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "prevValidating", void 0), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "errors", EMPTY_ERRORS), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "warnings", EMPTY_WARNINGS), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "cancelRegister", ()=>{
            const { preserve, isListField, name } = this.props;
            if (this.cancelRegisterFunc) {
                this.cancelRegisterFunc(isListField, preserve, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$valueUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getNamePath"])(name));
            }
            this.cancelRegisterFunc = null;
        }), // ================================== Utils ==================================
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "getNamePath", ()=>{
            const { name, fieldContext } = this.props;
            const { prefixName = [] } = fieldContext;
            return name !== undefined ? [
                ...prefixName,
                ...name
            ] : [];
        }), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "getRules", ()=>{
            const { rules = [], fieldContext } = this.props;
            return rules.map((rule)=>{
                if (typeof rule === 'function') {
                    return rule(fieldContext);
                }
                return rule;
            });
        }), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "refresh", ()=>{
            if (!this.mounted) return;
            /**
     * Clean up current node.
     */ this.setState((param)=>{
                let { resetCount } = param;
                return {
                    resetCount: resetCount + 1
                };
            });
        }), // Event should only trigger when meta changed
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "metaCache", null), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "triggerMetaEvent", (destroy)=>{
            const { onMetaChange } = this.props;
            if (onMetaChange) {
                const meta = {
                    ...this.getMeta(),
                    destroy
                };
                if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$isEqual$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(this.metaCache, meta)) {
                    onMetaChange(meta);
                }
                this.metaCache = meta;
            } else {
                this.metaCache = null;
            }
        }), // ========================= Field Entity Interfaces =========================
        // Trigger by store update. Check if need update the component
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "onStoreChange", (prevStore, namePathList, info)=>{
            const { shouldUpdate, dependencies = [], onReset } = this.props;
            const { store } = info;
            const namePath = this.getNamePath();
            const prevValue = this.getValue(prevStore);
            const curValue = this.getValue(store);
            const namePathMatch = namePathList && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$valueUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["containsNamePath"])(namePathList, namePath);
            // `setFieldsValue` is a quick access to update related status
            if (info.type === 'valueUpdate' && info.source === 'external' && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$isEqual$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(prevValue, curValue)) {
                this.touched = true;
                this.dirty = true;
                this.validatePromise = null;
                this.errors = EMPTY_ERRORS;
                this.warnings = EMPTY_WARNINGS;
                this.triggerMetaEvent();
            }
            switch(info.type){
                case 'reset':
                    if (!namePathList || namePathMatch) {
                        // Clean up state
                        this.touched = false;
                        this.dirty = false;
                        this.validatePromise = undefined;
                        this.errors = EMPTY_ERRORS;
                        this.warnings = EMPTY_WARNINGS;
                        this.triggerMetaEvent();
                        onReset === null || onReset === void 0 ? void 0 : onReset();
                        this.refresh();
                        return;
                    }
                    break;
                /**
       * In case field with `preserve = false` nest deps like:
       * - A = 1 => show B
       * - B = 1 => show C
       * - Reset A, need clean B, C
       */ case 'remove':
                    {
                        if (shouldUpdate && requireUpdate(shouldUpdate, prevStore, store, prevValue, curValue, info)) {
                            this.reRender();
                            return;
                        }
                        break;
                    }
                case 'setField':
                    {
                        const { data } = info;
                        if (namePathMatch) {
                            if ('touched' in data) {
                                this.touched = data.touched;
                            }
                            if ('validating' in data && !('originRCField' in data)) {
                                this.validatePromise = data.validating ? Promise.resolve([]) : null;
                            }
                            if ('errors' in data) {
                                this.errors = data.errors || EMPTY_ERRORS;
                            }
                            if ('warnings' in data) {
                                this.warnings = data.warnings || EMPTY_WARNINGS;
                            }
                            this.dirty = true;
                            this.triggerMetaEvent();
                            this.reRender();
                            return;
                        } else if ('value' in data && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$valueUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["containsNamePath"])(namePathList, namePath, true)) {
                            // Contains path with value should also check
                            this.reRender();
                            return;
                        }
                        // Handle update by `setField` with `shouldUpdate`
                        if (shouldUpdate && !namePath.length && requireUpdate(shouldUpdate, prevStore, store, prevValue, curValue, info)) {
                            this.reRender();
                            return;
                        }
                        break;
                    }
                case 'dependenciesUpdate':
                    {
                        /**
           * Trigger when marked `dependencies` updated. Related fields will all update
           */ const dependencyList = dependencies.map(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$valueUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getNamePath"]);
                        // No need for `namePathMath` check and `shouldUpdate` check, since `valueUpdate` will be
                        // emitted earlier and they will work there
                        // If set it may cause unnecessary twice rerendering
                        if (dependencyList.some((dependency)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$valueUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["containsNamePath"])(info.relatedFields, dependency))) {
                            this.reRender();
                            return;
                        }
                        break;
                    }
                default:
                    // 1. If `namePath` exists in `namePathList`, means it's related value and should update
                    //      For example <List name="list"><Field name={['list', 0]}></List>
                    //      If `namePathList` is [['list']] (List value update), Field should be updated
                    //      If `namePathList` is [['list', 0]] (Field value update), List shouldn't be updated
                    // 2.
                    //   2.1 If `dependencies` is set, `name` is not set and `shouldUpdate` is not set,
                    //       don't use `shouldUpdate`. `dependencies` is view as a shortcut if `shouldUpdate`
                    //       is not provided
                    //   2.2 If `shouldUpdate` provided, use customize logic to update the field
                    //       else to check if value changed
                    if (namePathMatch || (!dependencies.length || namePath.length || shouldUpdate) && requireUpdate(shouldUpdate, prevStore, store, prevValue, curValue, info)) {
                        this.reRender();
                        return;
                    }
                    break;
            }
            if (shouldUpdate === true) {
                this.reRender();
            }
        }), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "validateRules", (options)=>{
            // We should fixed namePath & value to avoid developer change then by form function
            const namePath = this.getNamePath();
            const currentValue = this.getValue();
            const { triggerName, validateOnly = false } = options || {};
            // Force change to async to avoid rule OOD under renderProps field
            const rootPromise = Promise.resolve().then(async ()=>{
                var _this = this;
                if (!this.mounted) {
                    return [];
                }
                const { validateFirst = false, messageVariables, validateDebounce } = this.props;
                // Start validate
                let filteredRules = this.getRules();
                if (triggerName) {
                    filteredRules = filteredRules.filter((rule)=>rule).filter((rule)=>{
                        const { validateTrigger } = rule;
                        if (!validateTrigger) {
                            return true;
                        }
                        const triggerList = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$typeUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toArray"])(validateTrigger);
                        return triggerList.includes(triggerName);
                    });
                }
                // Wait for debounce. Skip if no `triggerName` since its from `validateFields / submit`
                if (validateDebounce && triggerName) {
                    await new Promise((resolve)=>{
                        setTimeout(resolve, validateDebounce);
                    });
                    // Skip since out of date
                    if (this.validatePromise !== rootPromise) {
                        return [];
                    }
                }
                const promise = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$validateUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateRules"])(namePath, currentValue, filteredRules, options, validateFirst, messageVariables);
                promise.catch((e)=>e).then(function() {
                    let ruleErrors = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : EMPTY_ERRORS;
                    if (_this.validatePromise === rootPromise) {
                        var _ruleErrors_forEach;
                        _this.validatePromise = null;
                        // Get errors & warnings
                        const nextErrors = [];
                        const nextWarnings = [];
                        (_ruleErrors_forEach = ruleErrors.forEach) === null || _ruleErrors_forEach === void 0 ? void 0 : _ruleErrors_forEach.call(ruleErrors, (param)=>{
                            let { rule: { warningOnly }, errors = EMPTY_ERRORS } = param;
                            if (warningOnly) {
                                nextWarnings.push(...errors);
                            } else {
                                nextErrors.push(...errors);
                            }
                        });
                        _this.errors = nextErrors;
                        _this.warnings = nextWarnings;
                        _this.triggerMetaEvent();
                        _this.reRender();
                    }
                });
                return promise;
            });
            if (validateOnly) {
                return rootPromise;
            }
            this.validatePromise = rootPromise;
            this.dirty = true;
            this.errors = EMPTY_ERRORS;
            this.warnings = EMPTY_WARNINGS;
            this.triggerMetaEvent();
            // Force trigger re-render since we need sync renderProps with new meta
            this.reRender();
            return rootPromise;
        }), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "isFieldValidating", ()=>!!this.validatePromise), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "isFieldTouched", ()=>this.touched), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "isFieldDirty", ()=>{
            // Touched or validate or has initialValue
            if (this.dirty || this.props.initialValue !== undefined) {
                return true;
            }
            // Form set initialValue
            const { fieldContext } = this.props;
            const { getInitialValue } = fieldContext.getInternalHooks(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$FieldContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HOOK_MARK"]);
            if (getInitialValue(this.getNamePath()) !== undefined) {
                return true;
            }
            return false;
        }), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "getErrors", ()=>this.errors), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "getWarnings", ()=>this.warnings), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "isListField", ()=>this.props.isListField), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "isList", ()=>this.props.isList), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "isPreserve", ()=>this.props.preserve), // ============================= Child Component =============================
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "getMeta", ()=>{
            // Make error & validating in cache to save perf
            this.prevValidating = this.isFieldValidating();
            const meta = {
                touched: this.isFieldTouched(),
                validating: this.prevValidating,
                errors: this.errors,
                warnings: this.warnings,
                name: this.getNamePath(),
                validated: this.validatePromise === null
            };
            return meta;
        }), // Only return validate child node. If invalidate, will do nothing about field.
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "getOnlyChild", (children)=>{
            // Support render props
            if (typeof children === 'function') {
                const meta = this.getMeta();
                return {
                    ...this.getOnlyChild(children(this.getControlled(), meta, this.props.fieldContext)),
                    isFunction: true
                };
            }
            // Filed element only
            const childList = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$Children$2f$toArray$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(children);
            if (childList.length !== 1 || !/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isValidElement"](childList[0])) {
                return {
                    child: childList,
                    isFunction: false
                };
            }
            return {
                child: childList[0],
                isFunction: false
            };
        }), // ============================== Field Control ==============================
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "getValue", (store)=>{
            const { getFieldsValue } = this.props.fieldContext;
            const namePath = this.getNamePath();
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$utils$2f$get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__getValue$3e$__["getValue"])(store || getFieldsValue(true), namePath);
        }), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "getControlled", function() {
            let childProps = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
            var _this1 = _this;
            const { name, trigger = 'onChange', validateTrigger, getValueFromEvent, normalize, valuePropName = 'value', getValueProps, fieldContext } = _this.props;
            const mergedValidateTrigger = validateTrigger !== undefined ? validateTrigger : fieldContext.validateTrigger;
            const namePath = _this.getNamePath();
            const { getInternalHooks, getFieldsValue } = fieldContext;
            const { dispatch } = getInternalHooks(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$FieldContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HOOK_MARK"]);
            const value = _this.getValue();
            const mergedGetValueProps = getValueProps || ((val)=>({
                    [valuePropName]: val
                }));
            const originTriggerFunc = childProps[trigger];
            const valueProps = name !== undefined ? mergedGetValueProps(value) : {};
            // warning when prop value is function
            if (("TURBOPACK compile-time value", "development") !== 'production' && valueProps) {
                Object.keys(valueProps).forEach((key)=>{
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$warning$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(typeof valueProps[key] !== 'function', "It's not recommended to generate dynamic function prop by `getValueProps`. Please pass it to child component directly (prop: ".concat(key, ")"));
                });
            }
            const control = {
                ...childProps,
                ...valueProps
            };
            // Add trigger
            control[trigger] = function() {
                for(var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++){
                    args[_key] = arguments[_key];
                }
                // Mark as touched
                _this1.touched = true;
                _this1.dirty = true;
                _this1.triggerMetaEvent();
                let newValue;
                if (getValueFromEvent) {
                    newValue = getValueFromEvent(...args);
                } else {
                    newValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$valueUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["defaultGetValueFromEvent"])(valuePropName, ...args);
                }
                if (normalize) {
                    newValue = normalize(newValue, value, getFieldsValue(true));
                }
                if (newValue !== value) {
                    dispatch({
                        type: 'updateValue',
                        namePath,
                        value: newValue
                    });
                }
                if (originTriggerFunc) {
                    originTriggerFunc(...args);
                }
            };
            // Add validateTrigger
            const validateTriggerList = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$typeUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toArray"])(mergedValidateTrigger || []);
            validateTriggerList.forEach((triggerName)=>{
                var _this1 = _this;
                // Wrap additional function of component, so that we can get latest value from store
                const originTrigger = control[triggerName];
                control[triggerName] = function() {
                    for(var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++){
                        args[_key] = arguments[_key];
                    }
                    if (originTrigger) {
                        originTrigger(...args);
                    }
                    // Always use latest rules
                    const { rules } = _this1.props;
                    if (rules && rules.length) {
                        // We dispatch validate to root,
                        // since it will update related data with other field with same name
                        dispatch({
                            type: 'validateField',
                            namePath,
                            triggerName
                        });
                    }
                };
            });
            return control;
        });
        // Register on init
        if (props.fieldContext) {
            const { getInternalHooks } = props.fieldContext;
            const { initEntityValue } = getInternalHooks(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$FieldContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HOOK_MARK"]);
            initEntityValue(this);
        }
    }
}
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(Field, "contextType", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$FieldContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
function WrapperField(param) {
    let { name, ...restProps } = param;
    const fieldContext = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$FieldContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const listContext = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$ListContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const namePath = name !== undefined ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$valueUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getNamePath"])(name) : undefined;
    var _restProps_isListField;
    const isMergedListField = (_restProps_isListField = restProps.isListField) !== null && _restProps_isListField !== void 0 ? _restProps_isListField : !!listContext;
    let key = 'keep';
    if (!isMergedListField) {
        key = "_".concat((namePath || []).join('_'));
    }
    // Warning if it's a directly list field.
    // We can still support multiple level field preserve.
    if (("TURBOPACK compile-time value", "development") !== 'production' && restProps.preserve === false && isMergedListField && namePath.length <= 1) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$warning$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(false, '`preserve` should not apply on Form.List fields.');
    }
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"](Field, _extends({
        key: key,
        name: namePath,
        isListField: isMergedListField
    }, restProps, {
        fieldContext: fieldContext
    }));
}
const __TURBOPACK__default__export__ = WrapperField;
}),
"[project]/node_modules/@rc-component/form/es/List.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$warning$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/util/es/warning.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$FieldContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/form/es/FieldContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$Field$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/form/es/Field.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$valueUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/form/es/utils/valueUtil.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$ListContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/form/es/ListContext.js [app-client] (ecmascript)");
;
;
;
;
;
;
function List(param) {
    let { name, initialValue, children, rules, validateTrigger, isListField } = param;
    const context = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$FieldContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const wrapperListContext = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$ListContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const keyRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"]({
        keys: [],
        id: 0
    });
    const keyManager = keyRef.current;
    const prefixName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "List.useMemo[prefixName]": ()=>{
            const parentPrefixName = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$valueUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getNamePath"])(context.prefixName) || [];
            return [
                ...parentPrefixName,
                ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$valueUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getNamePath"])(name)
            ];
        }
    }["List.useMemo[prefixName]"], [
        context.prefixName,
        name
    ]);
    const fieldContext = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "List.useMemo[fieldContext]": ()=>({
                ...context,
                prefixName
            })
    }["List.useMemo[fieldContext]"], [
        context,
        prefixName
    ]);
    // List context
    const listContext = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "List.useMemo[listContext]": ()=>({
                getKey: ({
                    "List.useMemo[listContext]": (namePath)=>{
                        const len = prefixName.length;
                        const pathName = namePath[len];
                        return [
                            keyManager.keys[pathName],
                            namePath.slice(len + 1)
                        ];
                    }
                })["List.useMemo[listContext]"]
            })
    }["List.useMemo[listContext]"], [
        keyManager,
        prefixName
    ]);
    // User should not pass `children` as other type.
    if (typeof children !== 'function') {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$warning$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(false, 'Form.List only accepts function as children.');
        return null;
    }
    const shouldUpdate = (prevValue, nextValue, param)=>{
        let { source } = param;
        if (source === 'internal') {
            return false;
        }
        return prevValue !== nextValue;
    };
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$ListContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Provider, {
        value: listContext
    }, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$FieldContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Provider, {
        value: fieldContext
    }, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$Field$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        name: [],
        shouldUpdate: shouldUpdate,
        rules: rules,
        validateTrigger: validateTrigger,
        initialValue: initialValue,
        isList: true,
        isListField: isListField !== null && isListField !== void 0 ? isListField : !!wrapperListContext
    }, (param, meta)=>{
        let { value = [], onChange } = param;
        const { getFieldValue } = context;
        const getNewValue = ()=>{
            const values = getFieldValue(prefixName || []);
            return values || [];
        };
        /**
     * Always get latest value in case user update fields by `form` api.
     */ const operations = {
            add: (defaultValue, index)=>{
                // Mapping keys
                const newValue = getNewValue();
                if (index >= 0 && index <= newValue.length) {
                    keyManager.keys = [
                        ...keyManager.keys.slice(0, index),
                        keyManager.id,
                        ...keyManager.keys.slice(index)
                    ];
                    onChange([
                        ...newValue.slice(0, index),
                        defaultValue,
                        ...newValue.slice(index)
                    ]);
                } else {
                    if (("TURBOPACK compile-time value", "development") !== 'production' && (index < 0 || index > newValue.length)) {
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$warning$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(false, 'The second parameter of the add function should be a valid positive number.');
                    }
                    keyManager.keys = [
                        ...keyManager.keys,
                        keyManager.id
                    ];
                    onChange([
                        ...newValue,
                        defaultValue
                    ]);
                }
                keyManager.id += 1;
            },
            remove: (index)=>{
                const newValue = getNewValue();
                const indexSet = new Set(Array.isArray(index) ? index : [
                    index
                ]);
                if (indexSet.size <= 0) {
                    return;
                }
                keyManager.keys = keyManager.keys.filter((_, keysIndex)=>!indexSet.has(keysIndex));
                // Trigger store change
                onChange(newValue.filter((_, valueIndex)=>!indexSet.has(valueIndex)));
            },
            move (from, to) {
                if (from === to) {
                    return;
                }
                const newValue = getNewValue();
                // Do not handle out of range
                if (from < 0 || from >= newValue.length || to < 0 || to >= newValue.length) {
                    return;
                }
                keyManager.keys = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$valueUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["move"])(keyManager.keys, from, to);
                // Trigger store change
                onChange((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$valueUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["move"])(newValue, from, to));
            }
        };
        let listValue = value || [];
        if (!Array.isArray(listValue)) {
            listValue = [];
            if ("TURBOPACK compile-time truthy", 1) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$warning$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(false, "Current value of '".concat(prefixName.join(' > '), "' is not an array type."));
            }
        }
        return children(listValue.map((__, index)=>{
            let key = keyManager.keys[index];
            if (key === undefined) {
                keyManager.keys[index] = keyManager.id;
                key = keyManager.keys[index];
                keyManager.id += 1;
            }
            return {
                name: index,
                key,
                isListField: true
            };
        }), operations, meta);
    })));
}
const __TURBOPACK__default__export__ = List;
}),
"[project]/node_modules/@rc-component/form/es/utils/asyncUtil.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "allPromiseFinish",
    ()=>allPromiseFinish
]);
function allPromiseFinish(promiseList) {
    let hasError = false;
    let count = promiseList.length;
    const results = [];
    if (!promiseList.length) {
        return Promise.resolve([]);
    }
    return new Promise((resolve, reject)=>{
        promiseList.forEach((promise, index)=>{
            promise.catch((e)=>{
                hasError = true;
                return e;
            }).then((result)=>{
                count -= 1;
                results[index] = result;
                if (count > 0) {
                    return;
                }
                if (hasError) {
                    reject(results);
                }
                resolve(results);
            });
        });
    });
}
}),
"[project]/node_modules/@rc-component/form/es/utils/NameMap.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@swc/helpers/esm/_define_property.js [app-client] (ecmascript)");
;
const SPLIT = '__@field_split__';
/**
 * Convert name path into string to fast the fetch speed of Map.
 */ function normalize(namePath) {
    return namePath.map((cell)=>"".concat(typeof cell, ":").concat(cell))// Magic split
    .join(SPLIT);
}
/**
 * NameMap like a `Map` but accepts `string[]` as key.
 */ class NameMap {
    set(key, value) {
        this.kvs.set(normalize(key), value);
    }
    get(key) {
        return this.kvs.get(normalize(key));
    }
    getAsPrefix(key) {
        const normalizedKey = normalize(key);
        const normalizedPrefix = normalizedKey + SPLIT;
        const results = [];
        const current = this.kvs.get(normalizedKey);
        if (current !== undefined) {
            results.push(current);
        }
        this.kvs.forEach((value, itemNormalizedKey)=>{
            if (itemNormalizedKey.startsWith(normalizedPrefix)) {
                results.push(value);
            }
        });
        return results;
    }
    update(key, updater) {
        const origin = this.get(key);
        const next = updater(origin);
        if (!next) {
            this.delete(key);
        } else {
            this.set(key, next);
        }
    }
    delete(key) {
        this.kvs.delete(normalize(key));
    }
    // Since we only use this in test, let simply realize this
    map(callback) {
        return [
            ...this.kvs.entries()
        ].map((param)=>{
            let [key, value] = param;
            const cells = key.split(SPLIT);
            return callback({
                key: cells.map((cell)=>{
                    const [, type, unit] = cell.match(/^([^:]*):(.*)$/);
                    return type === 'number' ? Number(unit) : unit;
                }),
                value
            });
        });
    }
    toJSON() {
        const json = {};
        this.map((param)=>{
            let { key, value } = param;
            json[key.join('.')] = value;
            return null;
        });
        return json;
    }
    constructor(){
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "kvs", new Map());
    }
}
const __TURBOPACK__default__export__ = NameMap;
}),
"[project]/node_modules/@rc-component/form/es/hooks/useNotifyWatch.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>WatcherCenter
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@swc/helpers/esm/_define_property.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$valueUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/form/es/utils/valueUtil.js [app-client] (ecmascript) <locals>");
;
;
/**
 * Call action with delay in macro task.
 */ const macroTask = (fn)=>{
    const channel = new MessageChannel();
    channel.port1.onmessage = fn;
    channel.port2.postMessage(null);
};
class WatcherCenter {
    register(callback) {
        this.watcherList.add(callback);
        return ()=>{
            this.watcherList.delete(callback);
        };
    }
    notify(namePath) {
        // Insert with deduplication
        namePath.forEach((path)=>{
            if (this.namePathList.every((exist)=>!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$valueUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["matchNamePath"])(exist, path))) {
                this.namePathList.push(path);
            }
        });
        this.doBatch();
    }
    doBatch() {
        this.taskId += 1;
        const currentId = this.taskId;
        macroTask(()=>{
            if (currentId === this.taskId && this.watcherList.size) {
                const formInst = this.form.getForm();
                const values = formInst.getFieldsValue();
                const allValues = formInst.getFieldsValue(true);
                this.watcherList.forEach((callback)=>{
                    callback(values, allValues, this.namePathList);
                });
                this.namePathList = [];
            }
        });
    }
    constructor(form){
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "namePathList", []);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "taskId", 0);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "watcherList", new Set());
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "form", void 0);
        this.form = form;
    }
}
;
}),
"[project]/node_modules/@rc-component/form/es/hooks/useForm.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FormStore",
    ()=>FormStore,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@swc/helpers/esm/_define_property.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$utils$2f$set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/util/es/utils/set.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/util/es/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$warning$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/util/es/warning.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$FieldContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/form/es/FieldContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$asyncUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/form/es/utils/asyncUtil.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$messages$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/form/es/utils/messages.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$NameMap$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/form/es/utils/NameMap.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$valueUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/form/es/utils/valueUtil.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$utils$2f$get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__getValue$3e$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/util/es/utils/get.js [app-client] (ecmascript) <export default as getValue>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$utils$2f$set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__setValue$3e$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/util/es/utils/set.js [app-client] (ecmascript) <export default as setValue>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$hooks$2f$useNotifyWatch$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/form/es/hooks/useNotifyWatch.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
class FormStore {
    constructor(forceRootUpdate){
        var _this = this;
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "formHooked", false);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "forceRootUpdate", void 0);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "subscribable", true);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "store", {});
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "fieldEntities", []);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "initialValues", {});
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "callbacks", {});
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "validateMessages", null);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "preserve", null);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "lastValidatePromise", null);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "watcherCenter", new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$hooks$2f$useNotifyWatch$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"](this));
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "getForm", ()=>({
                getFieldValue: this.getFieldValue,
                getFieldsValue: this.getFieldsValue,
                getFieldError: this.getFieldError,
                getFieldWarning: this.getFieldWarning,
                getFieldsError: this.getFieldsError,
                isFieldsTouched: this.isFieldsTouched,
                isFieldTouched: this.isFieldTouched,
                isFieldValidating: this.isFieldValidating,
                isFieldsValidating: this.isFieldsValidating,
                resetFields: this.resetFields,
                setFields: this.setFields,
                setFieldValue: this.setFieldValue,
                setFieldsValue: this.setFieldsValue,
                validateFields: this.validateFields,
                submit: this.submit,
                _init: true,
                getInternalHooks: this.getInternalHooks
            }));
        // ======================== Internal Hooks ========================
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "getInternalHooks", (key)=>{
            if (key === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$FieldContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HOOK_MARK"]) {
                this.formHooked = true;
                return {
                    dispatch: this.dispatch,
                    initEntityValue: this.initEntityValue,
                    registerField: this.registerField,
                    useSubscribe: this.useSubscribe,
                    setInitialValues: this.setInitialValues,
                    destroyForm: this.destroyForm,
                    setCallbacks: this.setCallbacks,
                    setValidateMessages: this.setValidateMessages,
                    getFields: this.getFields,
                    setPreserve: this.setPreserve,
                    getInitialValue: this.getInitialValue,
                    registerWatch: this.registerWatch
                };
            }
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$warning$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(false, '`getInternalHooks` is internal usage. Should not call directly.');
            return null;
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "useSubscribe", (subscribable)=>{
            this.subscribable = subscribable;
        });
        /**
   * Record prev Form unmount fieldEntities which config preserve false.
   * This need to be refill with initialValues instead of store value.
   */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "prevWithoutPreserves", null);
        /**
   * First time `setInitialValues` should update store with initial value
   */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "setInitialValues", (initialValues, init)=>{
            this.initialValues = initialValues || {};
            if (init) {
                var // We will take consider prev form unmount fields.
                // When the field is not `preserve`, we need fill this with initialValues instead of store.
                // eslint-disable-next-line array-callback-return
                _this_prevWithoutPreserves;
                let nextStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$utils$2f$set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["merge"])(initialValues, this.store);
                (_this_prevWithoutPreserves = this.prevWithoutPreserves) === null || _this_prevWithoutPreserves === void 0 ? void 0 : _this_prevWithoutPreserves.map((param)=>{
                    let { key: namePath } = param;
                    nextStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$utils$2f$set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__setValue$3e$__["setValue"])(nextStore, namePath, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$utils$2f$get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__getValue$3e$__["getValue"])(initialValues, namePath));
                });
                this.prevWithoutPreserves = null;
                this.updateStore(nextStore);
            }
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "destroyForm", (clearOnDestroy)=>{
            if (clearOnDestroy) {
                // destroy form reset store
                this.updateStore({});
            } else {
                // Fill preserve fields
                const prevWithoutPreserves = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$NameMap$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]();
                this.getFieldEntities(true).forEach((entity)=>{
                    if (!this.isMergedPreserve(entity.isPreserve())) {
                        prevWithoutPreserves.set(entity.getNamePath(), true);
                    }
                });
                this.prevWithoutPreserves = prevWithoutPreserves;
            }
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "getInitialValue", (namePath)=>{
            const initValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$utils$2f$get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__getValue$3e$__["getValue"])(this.initialValues, namePath);
            // Not cloneDeep when without `namePath`
            return namePath.length ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$utils$2f$set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["merge"])(initValue) : initValue;
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "setCallbacks", (callbacks)=>{
            this.callbacks = callbacks;
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "setValidateMessages", (validateMessages)=>{
            this.validateMessages = validateMessages;
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "setPreserve", (preserve)=>{
            this.preserve = preserve;
        });
        // ============================= Watch ============================
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "registerWatch", (callback)=>{
            return this.watcherCenter.register(callback);
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "notifyWatch", function() {
            let namePath = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : [];
            _this.watcherCenter.notify(namePath);
        });
        // ========================== Dev Warning =========================
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "timeoutId", null);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "warningUnhooked", ()=>{
            if (("TURBOPACK compile-time value", "development") !== 'production' && !this.timeoutId && typeof window !== 'undefined') {
                this.timeoutId = setTimeout(()=>{
                    this.timeoutId = null;
                    if (!this.formHooked) {
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$warning$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(false, 'Instance created by `useForm` is not connected to any Form element. Forget to pass `form` prop?');
                    }
                });
            }
        });
        // ============================ Store =============================
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "updateStore", (nextStore)=>{
            this.store = nextStore;
        });
        // ============================ Fields ============================
        /**
   * Get registered field entities.
   * @param pure Only return field which has a `name`. Default: false
   */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "getFieldEntities", function() {
            let pure = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : false;
            if (!pure) {
                return _this.fieldEntities;
            }
            return _this.fieldEntities.filter((field)=>field.getNamePath().length);
        });
        /**
   * Get a map of registered field entities with their name path as the key.
   * @param pure Only include fields which have a `name`. Default: false
   * @returns A NameMap containing field entities indexed by their name paths
   */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "getFieldsMap", function() {
            let pure = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : false;
            const cache = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$NameMap$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]();
            _this.getFieldEntities(pure).forEach((field)=>{
                const namePath = field.getNamePath();
                cache.set(namePath, field);
            });
            return cache;
        });
        /**
   * Get field entities based on a list of name paths.
   * @param nameList - Array of name paths to search for. If not provided, returns all field entities with names.
   * @param includesSubNamePath - Whether to include fields that have the given name path as a prefix.
   */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "getFieldEntitiesForNamePathList", function(nameList) {
            let includesSubNamePath = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : false;
            if (!nameList) {
                return _this.getFieldEntities(true);
            }
            const cache = _this.getFieldsMap(true);
            if (!includesSubNamePath) {
                return nameList.map((name)=>{
                    const namePath = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$valueUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getNamePath"])(name);
                    return cache.get(namePath) || {
                        INVALIDATE_NAME_PATH: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$valueUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getNamePath"])(name)
                    };
                });
            }
            return nameList.flatMap((name)=>{
                const namePath = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$valueUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getNamePath"])(name);
                const fields = cache.getAsPrefix(namePath);
                if (fields.length) {
                    return fields;
                }
                return [
                    {
                        INVALIDATE_NAME_PATH: namePath
                    }
                ];
            });
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "getFieldsValue", (nameList, filterFunc)=>{
            this.warningUnhooked();
            // Fill args
            let mergedNameList;
            let mergedFilterFunc;
            if (nameList === true || Array.isArray(nameList)) {
                mergedNameList = nameList;
                mergedFilterFunc = filterFunc;
            } else if (nameList && typeof nameList === 'object') {
                mergedFilterFunc = nameList.filter;
            }
            if (mergedNameList === true && !mergedFilterFunc) {
                return this.store;
            }
            const fieldEntities = this.getFieldEntitiesForNamePathList(Array.isArray(mergedNameList) ? mergedNameList : null, true);
            const filteredNameList = [];
            const listNamePaths = [];
            fieldEntities.forEach((entity)=>{
                var _entity_isList;
                const namePath = entity.INVALIDATE_NAME_PATH || entity.getNamePath();
                // Ignore when it's a list item and not specific the namePath,
                // since parent field is already take in count
                if ((_entity_isList = entity.isList) === null || _entity_isList === void 0 ? void 0 : _entity_isList.call(entity)) {
                    listNamePaths.push(namePath);
                    return;
                }
                if (!mergedFilterFunc) {
                    filteredNameList.push(namePath);
                } else {
                    const meta = 'getMeta' in entity ? entity.getMeta() : null;
                    if (mergedFilterFunc(meta)) {
                        filteredNameList.push(namePath);
                    }
                }
            });
            let mergedValues = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$valueUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["cloneByNamePathList"])(this.store, filteredNameList.map(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$valueUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getNamePath"]));
            // We need fill the list as [] if Form.List is empty
            listNamePaths.forEach((namePath)=>{
                if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$utils$2f$get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__getValue$3e$__["getValue"])(mergedValues, namePath)) {
                    mergedValues = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$utils$2f$set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__setValue$3e$__["setValue"])(mergedValues, namePath, []);
                }
            });
            return mergedValues;
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "getFieldValue", (name)=>{
            this.warningUnhooked();
            const namePath = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$valueUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getNamePath"])(name);
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$utils$2f$get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__getValue$3e$__["getValue"])(this.store, namePath);
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "getFieldsError", (nameList)=>{
            this.warningUnhooked();
            const fieldEntities = this.getFieldEntitiesForNamePathList(nameList);
            return fieldEntities.map((entity, index)=>{
                if (entity && !entity.INVALIDATE_NAME_PATH) {
                    return {
                        name: entity.getNamePath(),
                        errors: entity.getErrors(),
                        warnings: entity.getWarnings()
                    };
                }
                return {
                    name: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$valueUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getNamePath"])(nameList[index]),
                    errors: [],
                    warnings: []
                };
            });
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "getFieldError", (name)=>{
            this.warningUnhooked();
            const namePath = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$valueUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getNamePath"])(name);
            const fieldError = this.getFieldsError([
                namePath
            ])[0];
            return fieldError.errors;
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "getFieldWarning", (name)=>{
            this.warningUnhooked();
            const namePath = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$valueUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getNamePath"])(name);
            const fieldError = this.getFieldsError([
                namePath
            ])[0];
            return fieldError.warnings;
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "isFieldsTouched", function() {
            for(var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++){
                args[_key] = arguments[_key];
            }
            _this.warningUnhooked();
            const [arg0, arg1] = args;
            let namePathList;
            let isAllFieldsTouched = false;
            if (args.length === 0) {
                namePathList = null;
            } else if (args.length === 1) {
                if (Array.isArray(arg0)) {
                    namePathList = arg0.map(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$valueUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getNamePath"]);
                    isAllFieldsTouched = false;
                } else {
                    namePathList = null;
                    isAllFieldsTouched = arg0;
                }
            } else {
                namePathList = arg0.map(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$valueUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getNamePath"]);
                isAllFieldsTouched = arg1;
            }
            const fieldEntities = _this.getFieldEntities(true);
            const isFieldTouched = (field)=>field.isFieldTouched();
            // ===== Will get fully compare when not config namePathList =====
            if (!namePathList) {
                return isAllFieldsTouched ? fieldEntities.every((entity)=>isFieldTouched(entity) || entity.isList()) : fieldEntities.some(isFieldTouched);
            }
            // Generate a nest tree for validate
            const map = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$NameMap$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]();
            namePathList.forEach((shortNamePath)=>{
                map.set(shortNamePath, []);
            });
            fieldEntities.forEach((field)=>{
                const fieldNamePath = field.getNamePath();
                // Find matched entity and put into list
                namePathList.forEach((shortNamePath)=>{
                    if (shortNamePath.every((nameUnit, i)=>fieldNamePath[i] === nameUnit)) {
                        map.update(shortNamePath, (list)=>[
                                ...list,
                                field
                            ]);
                    }
                });
            });
            // Check if NameMap value is touched
            const isNamePathListTouched = (entities)=>entities.some(isFieldTouched);
            const namePathListEntities = map.map((param)=>{
                let { value } = param;
                return value;
            });
            return isAllFieldsTouched ? namePathListEntities.every(isNamePathListTouched) : namePathListEntities.some(isNamePathListTouched);
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "isFieldTouched", (name)=>{
            this.warningUnhooked();
            return this.isFieldsTouched([
                name
            ]);
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "isFieldsValidating", (nameList)=>{
            this.warningUnhooked();
            const fieldEntities = this.getFieldEntities();
            if (!nameList) {
                return fieldEntities.some((testField)=>testField.isFieldValidating());
            }
            const namePathList = nameList.map(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$valueUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getNamePath"]);
            return fieldEntities.some((testField)=>{
                const fieldNamePath = testField.getNamePath();
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$valueUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["containsNamePath"])(namePathList, fieldNamePath) && testField.isFieldValidating();
            });
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "isFieldValidating", (name)=>{
            this.warningUnhooked();
            return this.isFieldsValidating([
                name
            ]);
        });
        /**
   * Reset Field with field `initialValue` prop.
   * Can pass `entities` or `namePathList` or just nothing.
   */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "resetWithFieldInitialValue", function() {
            let info = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
            // Create cache
            const cache = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$NameMap$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]();
            const fieldEntities = _this.getFieldEntities(true);
            fieldEntities.forEach((field)=>{
                const { initialValue } = field.props;
                const namePath = field.getNamePath();
                // Record only if has `initialValue`
                if (initialValue !== undefined) {
                    const records = cache.get(namePath) || new Set();
                    records.add({
                        entity: field,
                        value: initialValue
                    });
                    cache.set(namePath, records);
                }
            });
            // Reset
            const resetWithFields = (entities)=>{
                entities.forEach((field)=>{
                    const { initialValue } = field.props;
                    if (initialValue !== undefined) {
                        const namePath = field.getNamePath();
                        const formInitialValue = _this.getInitialValue(namePath);
                        if (formInitialValue !== undefined) {
                            // Warning if conflict with form initialValues and do not modify value
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$warning$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(false, "Form already set 'initialValues' with path '".concat(namePath.join('.'), "'. Field can not overwrite it."));
                        } else {
                            const records = cache.get(namePath);
                            if (records && records.size > 1) {
                                // Warning if multiple field set `initialValue`and do not modify value
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$warning$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(false, "Multiple Field with path '".concat(namePath.join('.'), "' set 'initialValue'. Can not decide which one to pick."));
                            } else if (records) {
                                const originValue = _this.getFieldValue(namePath);
                                const isListField = field.isListField();
                                // Set `initialValue`
                                if (!isListField && (!info.skipExist || originValue === undefined)) {
                                    _this.updateStore((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$utils$2f$set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__setValue$3e$__["setValue"])(_this.store, namePath, [
                                        ...records
                                    ][0].value));
                                }
                            }
                        }
                    }
                });
            };
            let requiredFieldEntities;
            if (info.entities) {
                requiredFieldEntities = info.entities;
            } else if (info.namePathList) {
                requiredFieldEntities = [];
                info.namePathList.forEach((namePath)=>{
                    const records = cache.get(namePath);
                    if (records) {
                        requiredFieldEntities.push(...[
                            ...records
                        ].map((r)=>r.entity));
                    }
                });
            } else {
                requiredFieldEntities = fieldEntities;
            }
            resetWithFields(requiredFieldEntities);
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "resetFields", (nameList)=>{
            this.warningUnhooked();
            const prevStore = this.store;
            if (!nameList) {
                this.updateStore((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$utils$2f$set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["merge"])(this.initialValues));
                this.resetWithFieldInitialValue();
                this.notifyObservers(prevStore, null, {
                    type: 'reset'
                });
                this.notifyWatch();
                return;
            }
            // Reset by `nameList`
            const namePathList = nameList.map(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$valueUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getNamePath"]);
            namePathList.forEach((namePath)=>{
                const initialValue = this.getInitialValue(namePath);
                this.updateStore((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$utils$2f$set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__setValue$3e$__["setValue"])(this.store, namePath, initialValue));
            });
            this.resetWithFieldInitialValue({
                namePathList
            });
            this.notifyObservers(prevStore, namePathList, {
                type: 'reset'
            });
            this.notifyWatch(namePathList);
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "setFields", (fields)=>{
            this.warningUnhooked();
            const prevStore = this.store;
            const namePathList = [];
            fields.forEach((fieldData)=>{
                const { name, ...data } = fieldData;
                const namePath = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$valueUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getNamePath"])(name);
                namePathList.push(namePath);
                // Value
                if ('value' in data) {
                    this.updateStore((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$utils$2f$set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__setValue$3e$__["setValue"])(this.store, namePath, data.value));
                }
                this.notifyObservers(prevStore, [
                    namePath
                ], {
                    type: 'setField',
                    data: fieldData
                });
            });
            this.notifyWatch(namePathList);
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "getFields", ()=>{
            const entities = this.getFieldEntities(true);
            const fields = entities.map((field)=>{
                const namePath = field.getNamePath();
                const meta = field.getMeta();
                const fieldData = {
                    ...meta,
                    name: namePath,
                    value: this.getFieldValue(namePath)
                };
                Object.defineProperty(fieldData, 'originRCField', {
                    value: true
                });
                return fieldData;
            });
            return fields;
        });
        // =========================== Observer ===========================
        /**
   * This only trigger when a field is on constructor to avoid we get initialValue too late
   */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "initEntityValue", (entity)=>{
            const { initialValue } = entity.props;
            if (initialValue !== undefined) {
                const namePath = entity.getNamePath();
                const prevValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$utils$2f$get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__getValue$3e$__["getValue"])(this.store, namePath);
                if (prevValue === undefined) {
                    this.updateStore((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$utils$2f$set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__setValue$3e$__["setValue"])(this.store, namePath, initialValue));
                }
            }
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "isMergedPreserve", (fieldPreserve)=>{
            const mergedPreserve = fieldPreserve !== undefined ? fieldPreserve : this.preserve;
            return mergedPreserve !== null && mergedPreserve !== void 0 ? mergedPreserve : true;
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "registerField", (entity)=>{
            var _this = this;
            this.fieldEntities.push(entity);
            const namePath = entity.getNamePath();
            this.notifyWatch([
                namePath
            ]);
            // Set initial values
            if (entity.props.initialValue !== undefined) {
                const prevStore = this.store;
                this.resetWithFieldInitialValue({
                    entities: [
                        entity
                    ],
                    skipExist: true
                });
                this.notifyObservers(prevStore, [
                    entity.getNamePath()
                ], {
                    type: 'valueUpdate',
                    source: 'internal'
                });
            }
            // un-register field callback
            return function(isListField, preserve) {
                let subNamePath = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : [];
                _this.fieldEntities = _this.fieldEntities.filter((item)=>item !== entity);
                // Clean up store value if not preserve
                if (!_this.isMergedPreserve(preserve) && (!isListField || subNamePath.length > 1)) {
                    const defaultValue = isListField ? undefined : _this.getInitialValue(namePath);
                    if (namePath.length && _this.getFieldValue(namePath) !== defaultValue && _this.fieldEntities.every((field)=>// Only reset when no namePath exist
                        !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$valueUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["matchNamePath"])(field.getNamePath(), namePath))) {
                        const prevStore = _this.store;
                        _this.updateStore((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$utils$2f$set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__setValue$3e$__["setValue"])(prevStore, namePath, defaultValue, true));
                        // Notify that field is unmount
                        _this.notifyObservers(prevStore, [
                            namePath
                        ], {
                            type: 'remove'
                        });
                        // Dependencies update
                        _this.triggerDependenciesUpdate(prevStore, namePath);
                    }
                }
                _this.notifyWatch([
                    namePath
                ]);
            };
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "dispatch", (action)=>{
            switch(action.type){
                case 'updateValue':
                    {
                        const { namePath, value } = action;
                        this.updateValue(namePath, value);
                        break;
                    }
                case 'validateField':
                    {
                        const { namePath, triggerName } = action;
                        this.validateFields([
                            namePath
                        ], {
                            triggerName
                        });
                        break;
                    }
                default:
            }
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "notifyObservers", (prevStore, namePathList, info)=>{
            if (this.subscribable) {
                const mergedInfo = {
                    ...info,
                    store: this.getFieldsValue(true)
                };
                this.getFieldEntities().forEach((param)=>{
                    let { onStoreChange } = param;
                    onStoreChange(prevStore, namePathList, mergedInfo);
                });
            } else {
                this.forceRootUpdate();
            }
        });
        /**
   * Notify dependencies children with parent update
   * We need delay to trigger validate in case Field is under render props
   */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "triggerDependenciesUpdate", (prevStore, namePath)=>{
            const childrenFields = this.getDependencyChildrenFields(namePath);
            if (childrenFields.length) {
                this.validateFields(childrenFields);
            }
            this.notifyObservers(prevStore, childrenFields, {
                type: 'dependenciesUpdate',
                relatedFields: [
                    namePath,
                    ...childrenFields
                ]
            });
            return childrenFields;
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "updateValue", (name, value)=>{
            const namePath = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$valueUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getNamePath"])(name);
            const prevStore = this.store;
            this.updateStore((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$utils$2f$set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__setValue$3e$__["setValue"])(this.store, namePath, value));
            this.notifyObservers(prevStore, [
                namePath
            ], {
                type: 'valueUpdate',
                source: 'internal'
            });
            this.notifyWatch([
                namePath
            ]);
            // Dependencies update
            const childrenFields = this.triggerDependenciesUpdate(prevStore, namePath);
            // trigger callback function
            const { onValuesChange } = this.callbacks;
            if (onValuesChange) {
                const fieldEntity = this.getFieldsMap(true).get(namePath);
                const changedValues = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$valueUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["cloneByNamePathList"])(this.store, [
                    namePath
                ]);
                const allValues = this.getFieldsValue();
                // Merge changedValues into allValues to ensure allValues contains the latest changes
                const mergedAllValues = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$utils$2f$set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeWith"])([
                    allValues,
                    changedValues
                ], {
                    // When value is array, it means trigger by Form.List which should replace directly
                    prepareArray: (current)=>(fieldEntity === null || fieldEntity === void 0 ? void 0 : fieldEntity.isList()) ? [] : [
                            ...current || []
                        ]
                });
                onValuesChange(changedValues, mergedAllValues);
            }
            this.triggerOnFieldsChange([
                namePath,
                ...childrenFields
            ]);
        });
        // Let all child Field get update.
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "setFieldsValue", (store)=>{
            this.warningUnhooked();
            const prevStore = this.store;
            if (store) {
                const nextStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$utils$2f$set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["merge"])(this.store, store);
                this.updateStore(nextStore);
            }
            this.notifyObservers(prevStore, null, {
                type: 'valueUpdate',
                source: 'external'
            });
            this.notifyWatch();
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "setFieldValue", (name, value)=>{
            this.setFields([
                {
                    name,
                    value,
                    errors: [],
                    warnings: [],
                    touched: true
                }
            ]);
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "getDependencyChildrenFields", (rootNamePath)=>{
            const children = new Set();
            const childrenFields = [];
            const dependencies2fields = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$NameMap$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]();
            /**
     * Generate maps
     * Can use cache to save perf if user report performance issue with this
     */ this.getFieldEntities().forEach((field)=>{
                const { dependencies } = field.props;
                (dependencies || []).forEach((dependency)=>{
                    const dependencyNamePath = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$valueUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getNamePath"])(dependency);
                    dependencies2fields.update(dependencyNamePath, function() {
                        let fields = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : new Set();
                        fields.add(field);
                        return fields;
                    });
                });
            });
            const fillChildren = (namePath)=>{
                const fields = dependencies2fields.get(namePath) || new Set();
                fields.forEach((field)=>{
                    if (!children.has(field)) {
                        children.add(field);
                        const fieldNamePath = field.getNamePath();
                        if (field.isFieldDirty() && fieldNamePath.length) {
                            childrenFields.push(fieldNamePath);
                            fillChildren(fieldNamePath);
                        }
                    }
                });
            };
            fillChildren(rootNamePath);
            return childrenFields;
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "triggerOnFieldsChange", (namePathList, filedErrors)=>{
            const { onFieldsChange } = this.callbacks;
            if (onFieldsChange) {
                const fields = this.getFields();
                /**
       * Fill errors since `fields` may be replaced by controlled fields
       */ if (filedErrors) {
                    const cache = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$NameMap$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]();
                    filedErrors.forEach((param)=>{
                        let { name, errors } = param;
                        cache.set(name, errors);
                    });
                    fields.forEach((field)=>{
                        // eslint-disable-next-line no-param-reassign
                        field.errors = cache.get(field.name) || field.errors;
                    });
                }
                const changedFields = fields.filter((param)=>{
                    let { name: fieldName } = param;
                    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$valueUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["containsNamePath"])(namePathList, fieldName);
                });
                if (changedFields.length) {
                    onFieldsChange(changedFields, fields);
                }
            }
        });
        // =========================== Validate ===========================
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "validateFields", (arg1, arg2)=>{
            this.warningUnhooked();
            let nameList;
            let options;
            if (Array.isArray(arg1) || typeof arg1 === 'string' || typeof arg2 === 'string') {
                nameList = arg1;
                options = arg2;
            } else {
                options = arg1;
            }
            const provideNameList = !!nameList;
            const namePathList = provideNameList ? nameList.map(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$valueUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getNamePath"]) : [];
            // Same namePathList, but does not include Form.List name
            const finalValueNamePathList = [
                ...namePathList
            ];
            // Collect result in promise list
            const promiseList = [];
            // We temp save the path which need trigger for `onFieldsChange`
            const TMP_SPLIT = String(Date.now());
            const validateNamePathList = new Set();
            const { recursive, dirty } = options || {};
            this.getFieldEntities(true).forEach((field)=>{
                const fieldNamePath = field.getNamePath();
                // Add field if not provide `nameList`
                if (!provideNameList) {
                    if (// If is field, pass directly
                    !field.isList() || // If is list, do not add if already exist sub field in the namePathList
                    !namePathList.some((name)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$valueUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["matchNamePath"])(name, fieldNamePath, true))) {
                        finalValueNamePathList.push(fieldNamePath);
                    }
                    namePathList.push(fieldNamePath);
                }
                // Skip if without rule
                if (!field.props.rules || !field.props.rules.length) {
                    return;
                }
                // Skip if only validate dirty field
                if (dirty && !field.isFieldDirty()) {
                    return;
                }
                validateNamePathList.add(fieldNamePath.join(TMP_SPLIT));
                // Add field validate rule in to promise list
                if (!provideNameList || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$valueUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["containsNamePath"])(namePathList, fieldNamePath, recursive)) {
                    const promise = field.validateRules({
                        validateMessages: {
                            ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$messages$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultValidateMessages"],
                            ...this.validateMessages
                        },
                        ...options
                    });
                    // Wrap promise with field
                    promiseList.push(promise.then(()=>({
                            name: fieldNamePath,
                            errors: [],
                            warnings: []
                        })).catch((ruleErrors)=>{
                        var _ruleErrors_forEach;
                        const mergedErrors = [];
                        const mergedWarnings = [];
                        (_ruleErrors_forEach = ruleErrors.forEach) === null || _ruleErrors_forEach === void 0 ? void 0 : _ruleErrors_forEach.call(ruleErrors, (param)=>{
                            let { rule: { warningOnly }, errors } = param;
                            if (warningOnly) {
                                mergedWarnings.push(...errors);
                            } else {
                                mergedErrors.push(...errors);
                            }
                        });
                        if (mergedErrors.length) {
                            return Promise.reject({
                                name: fieldNamePath,
                                errors: mergedErrors,
                                warnings: mergedWarnings
                            });
                        }
                        return {
                            name: fieldNamePath,
                            errors: mergedErrors,
                            warnings: mergedWarnings
                        };
                    }));
                }
            });
            const summaryPromise = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$asyncUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["allPromiseFinish"])(promiseList);
            this.lastValidatePromise = summaryPromise;
            // Notify fields with rule that validate has finished and need update
            summaryPromise.catch((results)=>results).then((results)=>{
                const resultNamePathList = results.map((param)=>{
                    let { name } = param;
                    return name;
                });
                this.notifyObservers(this.store, resultNamePathList, {
                    type: 'validateFinish'
                });
                this.triggerOnFieldsChange(resultNamePathList, results);
            });
            const returnPromise = summaryPromise.then(()=>{
                if (this.lastValidatePromise === summaryPromise) {
                    return Promise.resolve(this.getFieldsValue(finalValueNamePathList));
                }
                return Promise.reject([]);
            }).catch((results)=>{
                var _errorList__errors, _errorList_;
                const errorList = results.filter((result)=>result && result.errors.length);
                const errorMessage = (_errorList_ = errorList[0]) === null || _errorList_ === void 0 ? void 0 : (_errorList__errors = _errorList_.errors) === null || _errorList__errors === void 0 ? void 0 : _errorList__errors[0];
                return Promise.reject({
                    message: errorMessage,
                    values: this.getFieldsValue(namePathList),
                    errorFields: errorList,
                    outOfDate: this.lastValidatePromise !== summaryPromise
                });
            });
            // Do not throw in console
            returnPromise.catch((e)=>e);
            // `validating` changed. Trigger `onFieldsChange`
            const triggerNamePathList = namePathList.filter((namePath)=>validateNamePathList.has(namePath.join(TMP_SPLIT)));
            this.triggerOnFieldsChange(triggerNamePathList);
            return returnPromise;
        });
        // ============================ Submit ============================
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "submit", ()=>{
            this.warningUnhooked();
            this.validateFields().then((values)=>{
                const { onFinish } = this.callbacks;
                if (onFinish) {
                    try {
                        onFinish(values);
                    } catch (err) {
                        // Should print error if user `onFinish` callback failed
                        console.error(err);
                    }
                }
            }).catch((e)=>{
                const { onFinishFailed } = this.callbacks;
                if (onFinishFailed) {
                    onFinishFailed(e);
                }
            });
        });
        this.forceRootUpdate = forceRootUpdate;
    }
}
function useForm(form) {
    const formRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const [, forceUpdate] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]({});
    // Create singleton FormStore
    if (!formRef.current) {
        if (form) {
            formRef.current = form;
        } else {
            // Create a new FormStore if not provided
            const forceReRender = ()=>{
                forceUpdate({});
            };
            const formStore = new FormStore(forceReRender);
            formRef.current = formStore.getForm();
        }
    }
    return [
        formRef.current
    ];
}
const __TURBOPACK__default__export__ = useForm;
}),
"[project]/node_modules/@rc-component/form/es/FormContext.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FormProvider",
    ()=>FormProvider,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
const FormContext = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"]({
    triggerFormChange: ()=>{},
    triggerFormFinish: ()=>{},
    registerForm: ()=>{},
    unregisterForm: ()=>{}
});
const FormProvider = (param)=>{
    let { validateMessages, onFormChange, onFormFinish, children } = param;
    const formContext = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](FormContext);
    const formsRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"]({});
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"](FormContext.Provider, {
        value: {
            ...formContext,
            validateMessages: {
                ...formContext.validateMessages,
                ...validateMessages
            },
            // =========================================================
            // =                  Global Form Control                  =
            // =========================================================
            triggerFormChange: (name, changedFields)=>{
                if (onFormChange) {
                    onFormChange(name, {
                        changedFields,
                        forms: formsRef.current
                    });
                }
                formContext.triggerFormChange(name, changedFields);
            },
            triggerFormFinish: (name, values)=>{
                if (onFormFinish) {
                    onFormFinish(name, {
                        values,
                        forms: formsRef.current
                    });
                }
                formContext.triggerFormFinish(name, values);
            },
            registerForm: (name, form)=>{
                if (name) {
                    formsRef.current = {
                        ...formsRef.current,
                        [name]: form
                    };
                }
                formContext.registerForm(name, form);
            },
            unregisterForm: (name)=>{
                const newForms = {
                    ...formsRef.current
                };
                delete newForms[name];
                formsRef.current = newForms;
                formContext.unregisterForm(name);
            }
        }
    }, children);
};
;
const __TURBOPACK__default__export__ = FormContext;
}),
"[project]/node_modules/@rc-component/form/es/Form.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$hooks$2f$useForm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/form/es/hooks/useForm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$FieldContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/form/es/FieldContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$FormContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/form/es/FormContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$valueUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/form/es/utils/valueUtil.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$ListContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/form/es/ListContext.js [app-client] (ecmascript)");
function _extends() {
    _extends = ("TURBOPACK compile-time truthy", 1) ? Object.assign.bind() : "TURBOPACK unreachable";
    return _extends.apply(this, arguments);
}
;
;
;
;
;
;
const Form = (param, ref)=>{
    let { name, initialValues, fields, form, preserve, children, component: Component = 'form', validateMessages, validateTrigger = 'onChange', onValuesChange, onFieldsChange, onFinish, onFinishFailed, clearOnDestroy, ...restProps } = param;
    const nativeElementRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const formContext = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$FormContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    // We customize handle event since Context will makes all the consumer re-render:
    // https://reactjs.org/docs/context.html#contextprovider
    const [formInstance] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$hooks$2f$useForm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(form);
    const { useSubscribe, setInitialValues, setCallbacks, setValidateMessages, setPreserve, destroyForm } = formInstance.getInternalHooks(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$FieldContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HOOK_MARK"]);
    // Pass ref with form instance
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useImperativeHandle"](ref, {
        "Form.useImperativeHandle": ()=>({
                ...formInstance,
                nativeElement: nativeElementRef.current
            })
    }["Form.useImperativeHandle"]);
    // Register form into Context
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "Form.useEffect": ()=>{
            formContext.registerForm(name, formInstance);
            return ({
                "Form.useEffect": ()=>{
                    formContext.unregisterForm(name);
                }
            })["Form.useEffect"];
        }
    }["Form.useEffect"], [
        formContext,
        formInstance,
        name
    ]);
    // Pass props to store
    setValidateMessages({
        ...formContext.validateMessages,
        ...validateMessages
    });
    setCallbacks({
        onValuesChange,
        onFieldsChange: function(changedFields) {
            for(var _len = arguments.length, rest = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++){
                rest[_key - 1] = arguments[_key];
            }
            formContext.triggerFormChange(name, changedFields);
            if (onFieldsChange) {
                onFieldsChange(changedFields, ...rest);
            }
        },
        onFinish: (values)=>{
            formContext.triggerFormFinish(name, values);
            if (onFinish) {
                onFinish(values);
            }
        },
        onFinishFailed
    });
    setPreserve(preserve);
    // Set initial value, init store value when first mount
    const mountRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    setInitialValues(initialValues, !mountRef.current);
    if (!mountRef.current) {
        mountRef.current = true;
    }
    // ========================== Unmount ===========================
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "Form.useEffect": ()=>({
                "Form.useEffect": ()=>destroyForm(clearOnDestroy)
            })["Form.useEffect"]
    }["Form.useEffect"], // eslint-disable-next-line react-hooks/exhaustive-deps
    []);
    // Prepare children by `children` type
    let childrenNode;
    const childrenRenderProps = typeof children === 'function';
    if (childrenRenderProps) {
        const values = formInstance.getFieldsValue(true);
        childrenNode = children(values, formInstance);
    } else {
        childrenNode = children;
    }
    // Not use subscribe when using render props
    useSubscribe(!childrenRenderProps);
    // Listen if fields provided. We use ref to save prev data here to avoid additional render
    const prevFieldsRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "Form.useEffect": ()=>{
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$valueUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["isSimilar"])(prevFieldsRef.current || [], fields || [])) {
                formInstance.setFields(fields || []);
            }
            prevFieldsRef.current = fields;
        }
    }["Form.useEffect"], [
        fields,
        formInstance
    ]);
    // =========================== Render ===========================
    const formContextValue = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "Form.useMemo[formContextValue]": ()=>({
                ...formInstance,
                validateTrigger
            })
    }["Form.useMemo[formContextValue]"], [
        formInstance,
        validateTrigger
    ]);
    const wrapperNode = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$ListContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Provider, {
        value: null
    }, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$FieldContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Provider, {
        value: formContextValue
    }, childrenNode));
    if (Component === false) {
        return wrapperNode;
    }
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"](Component, _extends({}, restProps, {
        ref: nativeElementRef,
        onSubmit: (event)=>{
            event.preventDefault();
            event.stopPropagation();
            formInstance.submit();
        },
        onReset: (event)=>{
            var _restProps_onReset;
            event.preventDefault();
            formInstance.resetFields();
            (_restProps_onReset = restProps.onReset) === null || _restProps_onReset === void 0 ? void 0 : _restProps_onReset.call(restProps, event);
        }
    }), wrapperNode);
};
const __TURBOPACK__default__export__ = Form;
}),
"[project]/node_modules/@rc-component/form/es/hooks/useWatch.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "stringify",
    ()=>stringify
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$warning$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/util/es/warning.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$FieldContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/form/es/FieldContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$typeUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/form/es/utils/typeUtil.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$valueUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/form/es/utils/valueUtil.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$utils$2f$get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__getValue$3e$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/util/es/utils/get.js [app-client] (ecmascript) <export default as getValue>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/util/es/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$hooks$2f$useEvent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__useEvent$3e$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/util/es/hooks/useEvent.js [app-client] (ecmascript) <export default as useEvent>");
;
;
;
;
;
;
function stringify(value) {
    try {
        return JSON.stringify(value);
    } catch (e) {
        return Math.random();
    }
}
// ------- selector type -------
// ------- selector type end -------
function useWatch() {
    for(var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++){
        args[_key] = arguments[_key];
    }
    const [dependencies, _form = {}] = args;
    const options = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$typeUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFormInstance"])(_form) ? {
        form: _form
    } : _form;
    const form = options.form;
    const [value, setValue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        "useWatch.useState": ()=>typeof dependencies === 'function' ? dependencies({}) : undefined
    }["useWatch.useState"]);
    const valueStr = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useWatch.useMemo[valueStr]": ()=>stringify(value)
    }["useWatch.useMemo[valueStr]"], [
        value
    ]);
    const valueStrRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(valueStr);
    valueStrRef.current = valueStr;
    const fieldContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$FieldContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    const formInstance = form || fieldContext;
    const isValidForm = formInstance && formInstance._init;
    // Warning if not exist form instance
    if ("TURBOPACK compile-time truthy", 1) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$warning$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(args.length === 2 ? form ? isValidForm : true : isValidForm, 'useWatch requires a form instance since it can not auto detect from context.');
    }
    // ============================== Form ==============================
    const { getFieldsValue, getInternalHooks } = formInstance;
    const { registerWatch } = getInternalHooks(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$FieldContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HOOK_MARK"]);
    // ============================= Update =============================
    const triggerUpdate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$hooks$2f$useEvent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__useEvent$3e$__["useEvent"])({
        "useWatch.useEvent[triggerUpdate]": (values, allValues)=>{
            const watchValue = options.preserve ? allValues !== null && allValues !== void 0 ? allValues : getFieldsValue(true) : values !== null && values !== void 0 ? values : getFieldsValue();
            const nextValue = typeof dependencies === 'function' ? dependencies(watchValue) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$util$2f$es$2f$utils$2f$get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__getValue$3e$__["getValue"])(watchValue, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$utils$2f$valueUtil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getNamePath"])(dependencies));
            if (stringify(value) !== stringify(nextValue)) {
                setValue(nextValue);
            }
        }
    }["useWatch.useEvent[triggerUpdate]"]);
    // ============================= Effect =============================
    const flattenDeps = typeof dependencies === 'function' ? dependencies : JSON.stringify(dependencies);
    // Deps changed
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useWatch.useEffect": ()=>{
            // Skip if not exist form instance
            if (!isValidForm) {
                return;
            }
            triggerUpdate();
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }
    }["useWatch.useEffect"], [
        isValidForm,
        flattenDeps
    ]);
    // Value changed
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useWatch.useEffect": ()=>{
            // Skip if not exist form instance
            if (!isValidForm) {
                return;
            }
            const cancelRegister = registerWatch({
                "useWatch.useEffect.cancelRegister": (values, allValues)=>{
                    triggerUpdate(values, allValues);
                }
            }["useWatch.useEffect.cancelRegister"]);
            return cancelRegister;
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }
    }["useWatch.useEffect"], [
        isValidForm
    ]);
    return value;
}
const __TURBOPACK__default__export__ = useWatch;
}),
"[project]/node_modules/@rc-component/form/es/index.js [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$Field$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/form/es/Field.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/form/es/List.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$hooks$2f$useForm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/form/es/hooks/useForm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$Form$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/form/es/Form.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$FormContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/form/es/FormContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$FieldContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/form/es/FieldContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$ListContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/form/es/ListContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$hooks$2f$useWatch$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@rc-component/form/es/hooks/useWatch.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
const InternalForm = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$Form$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
const RefForm = InternalForm;
RefForm.FormProvider = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$FormContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FormProvider"];
RefForm.Field = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$Field$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
RefForm.List = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
RefForm.useForm = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$hooks$2f$useForm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
RefForm.useWatch = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$rc$2d$component$2f$form$2f$es$2f$hooks$2f$useWatch$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
;
const __TURBOPACK__default__export__ = RefForm;
}),
]);

//# sourceMappingURL=node_modules_%40rc-component_form_es_9e966f63._.js.map