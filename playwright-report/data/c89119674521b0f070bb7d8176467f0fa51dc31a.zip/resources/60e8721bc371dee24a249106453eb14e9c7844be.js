(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_e6c0030b._.js",
  "static/chunks/src_components_e6cd4fbf._.js"
],
    source: "dynamic"
});
